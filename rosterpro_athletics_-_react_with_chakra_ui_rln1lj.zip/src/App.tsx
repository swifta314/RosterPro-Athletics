import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';

// Layouts
import SidebarLayout from './views/Layout/SidebarLayout';

// Auth Flow
import Login from './views/AuthFlow/Login';
import Registration from './views/AuthFlow/Registration';

// Main Flow
import DashboardOverview from './views/MainFlow/DashboardOverview';

// Roster Management
import MultiYearPlanner from './views/RosterManagement/MultiYearPlanner';
import AthleteDetails from './views/RosterManagement/AthleteDetails';
import RosterTimeline from './views/RosterManagement/RosterTimeline';

// Scholarship Management
import ScholarshipTracker from './views/ScholarshipManagement/ScholarshipTracker';
import BudgetAllocation from './views/ScholarshipManagement/BudgetAllocation';

// Performance Management
import PerformanceAnalytics from './views/PerformanceManagement/PerformanceAnalytics';
import EventGroupAnalysis from './views/PerformanceManagement/EventGroupAnalysis';

// Compliance
import TitleIXMonitor from './views/Compliance/TitleIXMonitor';
import ComplianceCenter from './views/Compliance/ComplianceCenter';

// Configuration
import Settings from './views/Configuration/Settings';
import UserManagement from './views/Configuration/UserManagement';
import ProgramSettings from './views/Configuration/ProgramSettings';

// Analytics
import ReportsCenter from './views/Analytics/ReportsCenter';

// Recruitment
import TransferPortal from './views/Recruitment/TransferPortal';
import ProspectDetails from './views/Recruitment/ProspectDetails';

const App: React.FC = () => {
  return (
    <Routes>
      {/* Auth routes - no layout */}
      <Route path="/login" element={<Login />} />
      <Route path="/registration" element={<Registration />} />
      
      {/* Routes with sidebar layout */}
      <Route element={<SidebarLayout />}>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard" element={<DashboardOverview />} />
        
        {/* Roster Management */}
        <Route path="/roster-planner" element={<MultiYearPlanner />} />
        <Route path="/athlete-details" element={<AthleteDetails />} />
        <Route path="/roster-timeline" element={<RosterTimeline />} />
        
        {/* Scholarship Management */}
        <Route path="/scholarship-tracker" element={<ScholarshipTracker />} />
        <Route path="/budget-allocation" element={<BudgetAllocation />} />
        
        {/* Performance Management */}
        <Route path="/performance" element={<PerformanceAnalytics />} />
        <Route path="/event-analysis" element={<EventGroupAnalysis />} />
        
        {/* Compliance */}
        <Route path="/title-ix" element={<TitleIXMonitor />} />
        <Route path="/compliance" element={<ComplianceCenter />} />
        
        {/* Configuration */}
        <Route path="/settings" element={<Settings />} />
        <Route path="/user-management" element={<UserManagement />} />
        <Route path="/program-settings" element={<ProgramSettings />} />
        
        {/* Analytics */}
        <Route path="/reports" element={<ReportsCenter />} />
        
        {/* Recruitment */}
        <Route path="/transfer-portal" element={<TransferPortal />} />
        <Route path="/prospect-details" element={<ProspectDetails />} />
      </Route>
    </Routes>
  );
};

export default App;
