// This file will contain model definitions for the MVC architecture
export {};
