// Common types for the application
export {};
