//@ts-nocheck

import React, { useState } from 'react';
import { 
  ChakraProvider, 
  Flex, 
  Text, 
  Card, 
  Badge, 
  Tabs, 
  TabList, 
  Tab, 
  Grid, 
  Button, 
  InputGroup, 
  InputLeftElement, 
  Input, 
  Menu, 
  MenuButton, 
  Drawer, 
  DrawerContent, 
  DrawerHeader, 
  DrawerBody, 
  Select 
} from '@chakra-ui/react';
import { 
  IconCalendar, 
  IconDownload, 
  IconPlus, 
  IconCalendarEvent, 
  IconShare, 
  IconStar, 
  IconStarFilled 
} from '@tabler/icons-react';
import { kStyleGlobal } from '../theme';

const ReportsCenter = () => {
  const [isCustomReportOpen, setIsCustomReportOpen] = useState(false);
  const [isScheduleModalOpen, setIsScheduleModalOpen] = useState(false);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState("Performance");

  const categories = [
    { name: "Performance", count: 12 },
    { name: "Roster", count: 8 },
    { name: "Scholarship", count: 6 },
    { name: "Compliance", count: 4 }
  ];

  const [reports, setReports] = useState([
    {
      title: "Team Performance Analysis",
      description: "Comprehensive analysis of team metrics and KPIs",
      lastGenerated: "2024-01-15",
      frequency: "Weekly",
      type: "Performance",
      isFavorite: true
    },
    {
      title: "Roster Status Report",
      description: "Current roster composition and status updates",
      lastGenerated: "2024-01-14",
      frequency: "Daily",
      type: "Roster",
      isFavorite: false
    }
  ]);

  const toggleCustomReport = () => {
    setIsCustomReportOpen(!isCustomReportOpen);
  };

  const toggleScheduleModal = () => {
    setIsScheduleModalOpen(!isScheduleModalOpen);
  };

  const toggleShareModal = () => {
    setIsShareModalOpen(!isShareModalOpen);
  };

  return (
    <ChakraProvider theme={kStyleGlobal}>
      <Flex
        direction="column"
        p={6}
        gap={6}
      >
        <Flex
          justify="space-between"
          align="center"
          mb={2}
        >
          <Flex
            direction="column"
            gap={1}
          >
            <Text
              fontSize="2xl"
              fontWeight="bold"
            >
              Reports Center
            </Text>
            <Text
              color="gray.500"
            >
              Generate and manage your athletic program reports
            </Text>
          </Flex>
          <Flex gap={4}>
            <InputGroup>
              <InputLeftElement>
                <IconCalendar size={20} color="gray.400" />
              </InputLeftElement>
              <Input placeholder="Select date range" />
            </InputGroup>
            <Menu>
              <MenuButton
                as={Button}
                variant="secondary"
              >
                <Flex
                  align="center"
                  gap={2}
                >
                  <IconDownload size={20} />
                  <Text>Export</Text>
                </Flex>
              </MenuButton>
            </Menu>
            <Button onClick={toggleCustomReport}>
              <Flex
                align="center"
                gap={2}
              >
                <IconPlus size={20} />
                <Text>Create Custom Report</Text>
              </Flex>
            </Button>
          </Flex>
        </Flex>
        <Grid
          templateColumns="repeat(4, 1fr)"
          gap={6}
        >
          {categories.map(category => (
            <Card key={category.name}>
              <Flex
                direction="column"
                p={6}
                gap={4}
              >
                <Flex
                  justify="space-between"
                  align="center"
                >
                  <Text
                    fontWeight="semibold"
                  >
                    {category.name}
                  </Text>
                  <Badge
                    variant="subtle"
                    colorScheme="primary"
                  >
                    {category.count + " Reports"}
                  </Badge>
                </Flex>
              </Flex>
            </Card>
          ))}
        </Grid>
        <Tabs>
          <TabList>
            <Tab>All Reports</Tab>
            <Tab>Favorites</Tab>
            <Tab>Recent</Tab>