//@ts-nocheck

import React, { useState } from 'react';
import { 
  ChakraProvider, 
  Flex, 
  Box, 
  Text, 
  Input, 
  InputGroup, 
  InputLeftElement, 
  InputRightElement, 
  Checkbox, 
  Button, 
  Modal, 
  ModalOverlay, 
  ModalContent, 
  ModalHeader, 
  ModalBody, 
  ModalFooter 
} from '@chakra-ui/react';
import { 
  IconBuildingSkyscraper, 
  IconMail, 
  IconLock, 
  IconEye 
} from '@tabler/icons-react';
import { kStyleGlobal } from '../../theme';
import { useNavigate } from 'react-router-dom';

const Login = () => {
  const [isOpen, setIsOpen] = useState(false);
  const navigate = useNavigate();

  const toggleModal = () => {
    setIsOpen(!isOpen);
  };

  const handleLogin = () => {
    navigate('/dashboard');
  };

  const handleRegister = () => {
    navigate('/registration');
  };

  return (
    <ChakraProvider theme={kStyleGlobal}>
      <Flex
        minH="100vh"
        bg="background"
        justifyContent="center"
        alignItems="center"
        px={4}
      >
        <Flex
          direction="column"
          w="full"
          maxW="440px"
          bg="white"
          borderRadius="2xl"
          p={8}
          gap={6}
        >
          <Flex
            direction="column"
            align="center"
            gap={2}
          >
            <Box
              bg="primary.50"
              p={3}
              borderRadius="xl"
              color="primary.500"
            >
              <IconBuildingSkyscraper size={32} />
            </Box>
            <Text
              fontSize="2xl"
              fontWeight="bold"
            >
              RosterPro Athletics
            </Text>
          </Flex>
          <Flex
            direction="column"
            gap={4}
          >
            <InputGroup>
              <InputLeftElement pl={4}>
                <IconMail size={20} color="gray.400" />
              </InputLeftElement>
              <Input
                placeholder="University Email"
                type="email"
              />
            </InputGroup>
            <InputGroup>
              <InputLeftElement pl={4}>
                <IconLock size={20} color="gray.400" />
              </InputLeftElement>
              <Input
                placeholder="Password"
                type="password"
              />
              <InputRightElement pr={4}>
                <IconEye size={20} color="gray.400" />
              </InputRightElement>
            </InputGroup>
            <Flex
              justify="space-between"
              align="center"
            >
              <Checkbox colorScheme="primary">
                Remember me
              </Checkbox>
              <Button
                variant="link"
                onClick={toggleModal}
              >
                <Text color="primary.500">
                  Forgot Password?
                </Text>
              </Button>
            </Flex>
            <Button
              size="lg"
              w="full"
              onClick={handleLogin}
            >
              Login
            </Button>
            <Flex
              justify="center"
              gap={1}
            >
              <Text color="gray.500">
                Don't have an account?
              </Text>
              <Button
                variant="link"
                onClick={handleRegister}
              >
                <Text
                  color="primary.500"
                  fontWeight="semibold"
                >
                  Register
                </Text>
              </Button>
            </Flex>
          </Flex>
        </Flex>
      </Flex>
      <Modal
        isOpen={isOpen}
        onClose={toggleModal}
      >
        <ModalOverlay />
        <ModalContent
          borderRadius="2xl"
          p={6}
        >
          <ModalHeader
            p={0}
            mb={4}
          >
            <Text
              fontSize="xl"
              fontWeight="bold"
            >
              Reset Password
            </Text>
          </ModalHeader>
          <ModalBody p={0}>
            <Text
              color="gray.500"
              mb={4}
            >
              Enter your email address and we'll send you instructions to reset your password.
            </Text>
            <InputGroup>
              <InputLeftElement pl={4}>
                <IconMail size={20} color="gray.400" />
              </InputLeftElement>
              <Input placeholder="Email address" />
            </InputGroup>
          </ModalBody>
          <ModalFooter
            p={0}
            mt={6}
          >
            <Button
              w="full"
              onClick={toggleModal}
            >
              Send Reset Instructions
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </ChakraProvider>
  );
};

export default Login;
