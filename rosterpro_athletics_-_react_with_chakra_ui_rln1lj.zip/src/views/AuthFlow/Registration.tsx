//@ts-nocheck

import React, { useState } from 'react';
import { 
  ChakraProvider, 
  Flex, 
  Card, 
  Box, 
  Stack, 
  Select, 
  Input, 
  Checkbox, 
  Button, 
  Text 
} from '@chakra-ui/react';
import { IconBuildingCommunity } from '@tabler/icons-react';
import { useNavigate } from 'react-router-dom';
import { kStyleGlobal } from '../../theme';

const Registration: React.FC = () => {
  const [isFormValid, setIsFormValid] = useState(false);
  const navigate = useNavigate();

  const universities = ["Stanford University", "Harvard University", "MIT", "Yale University"];
  const roles = ["Head Coach", "Assistant Coach", "Compliance Officer", "Staff"];

  const validateForm = () => {
    setIsFormValid(true);
  };

  return (
    <ChakraProvider theme={kStyleGlobal}>
      <Flex
        minH="100vh"
        align="center"
        justify="center"
        bg="background"
        p={8}
      >
        <Card
          maxW="600px"
          w="full"
        >
          <Flex
            direction="column"
            p={8}
            gap={8}
          >
            <Flex
              direction="column"
              align="center"
              textAlign="center"
              mb={4}
            >
              <IconBuildingCommunity
                size={48}
                color={kStyleGlobal.colors.primary[500]}
              />
              <Text
                fontSize="2xl"
                fontWeight="bold"
                mt={4}
              >
                Create Your Account
              </Text>
              <Text
                color="gray.500"
                mt={2}
              >
                Join RosterPro Athletics to manage your athletic program
              </Text>
            </Flex>
            <Flex
              direction="column"
              gap={6}
            >
              <Box>
                <Text
                  fontWeight="semibold"
                  mb={4}
                >
                  Program Information
                </Text>
                <Stack gap={4}>
                  <Select placeholder="Select University">
                    {universities.map(uni => (
                      <option
                        value={uni}
                        key={uni}
                      >
                        {uni}
                      </option>
                    ))}
                  </Select>
                  <Input placeholder="Athletic Department" />
                </Stack>
              </Box>
              <Box>
                <Text
                  fontWeight="semibold"
                  mb={4}
                >
                  Personal Details
                </Text>
                <Stack gap={4}>
                  <Flex gap={4}>
                    <Input placeholder="First Name" />
                    <Input placeholder="Last Name" />
                  </Flex>
                  <Input
                    placeholder="Work Email"
                    type="email"
                  />
                  <Select placeholder="Select Role">
                    {roles.map(role => (
                      <option
                        value={role}
                        key={role}
                      >
                        {role}
                      </option>
                    ))}
                  </Select>
                </Stack>
              </Box>
              <Box>
                <Text
                  fontWeight="semibold"
                  mb={4}
                >
                  Security
                </Text>
                <Stack gap={4}>
                  <Input
                    type="password"
                    placeholder="Password"
                  />
                  <Input
                    type="password"
                    placeholder="Confirm Password"
                  />
                </Stack>
              </Box>
              <Checkbox>
                I agree to the Terms & Conditions
              </Checkbox>
              <Button
                isDisabled={!isFormValid}
                onClick={() => navigate('/dashboard')}
              >
                Create Account
              </Button>
              <Flex
                justify="center"
                gap={2}
              >
                <Text
                  color="gray.500"
                >
                  Already have an account?
                </Text>
                <Button
                  variant="link"
                  onClick={() => navigate('/login')}
                >
                  <Text
                    color="primary.500"
                  >
                    Sign in
                  </Text>
                </Button>
              </Flex>
            </Flex>
          </Flex>
        </Card>
      </Flex>
    </ChakraProvider>
  );
};

export default Registration;
