//@ts-nocheck

import React, { useState } from 'react';
import { 
  ChakraProvider, 
  Flex, 
  Text, 
  Button, 
  Grid, 
  Card, 
  Badge, 
  Stack, 
  Menu, 
  MenuButton, 
  Modal, 
  ModalOverlay, 
  ModalContent, 
  ModalHeader, 
  ModalCloseButton, 
  ModalBody, 
  ModalFooter, 
  FormControl, 
  FormLabel, 
  Select, 
  Input 
} from '@chakra-ui/react';
import { IconFileReport, IconFilter, IconUpload } from '@tabler/icons-react';
import { kStyleGlobal } from '../../theme';

const ComplianceCenter: React.FC = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedTab] = useState("overview");

  const complianceMetrics = [
    { title: "NCAA Roster Limits", value: "Compliant", status: "success" },
    { title: "Scholarship Allocation", value: "Warning", status: "warning" },
    { title: "Title IX Status", value: "Compliant", status: "success" }
  ];

  const alerts = [
    { title: "Scholarship Update Required", severity: "high", deadline: "Dec 15, 2023", category: "scholarship" },
    { title: "Roster Verification Needed", severity: "medium", deadline: "Dec 20, 2023", category: "roster" }
  ];

  const documents = [
    { title: "NCAA Compliance Report", status: "current", dueDate: "Jan 15, 2024" },
    { title: "Title IX Documentation", status: "expiring", dueDate: "Dec 30, 2023" }
  ];

  const toggleModal = () => {
    setIsModalOpen(!isModalOpen);
  };

  return (
    <ChakraProvider theme={kStyleGlobal}>
      <Flex direction="column" p={6} gap={6}>
        <Flex justify="space-between" align="center" mb={2}>
          <Flex direction="column">
            <Text fontSize="2xl" fontWeight="bold">Compliance Center</Text>
            <Text color="gray.500">Monitor and manage compliance requirements</Text>
          </Flex>
          <Button 
            leftIcon={<IconFileReport size={20} />} 
            onClick={toggleModal}
          >
            Generate Report
          </Button>
        </Flex>

        <Grid 
          templateColumns={{ base: "1fr", md: "repeat(3, 1fr)" }} 
          gap={6}
        >
          {complianceMetrics.map(metric => (
            <Card key={metric.title}>
              <Flex direction="column" p={6}>
                <Badge 
                  colorScheme={metric.status} 
                  mb={4} 
                  borderRadius="full"
                >
                  {metric.value}
                </Badge>
                <Text fontWeight="medium">{metric.title}</Text>
              </Flex>
            </Card>
          ))}
        </Grid>

        <Grid 
          templateColumns={{ base: "1fr", lg: "2fr 1fr" }} 
          gap={6}
        >
          <Card>
            <Flex direction="column" p={6}>
              <Flex justify="space-between" align="center" mb={6}>
                <Text fontSize="lg" fontWeight="bold">Active Alerts</Text>
                <Menu>
                  <MenuButton 
                    as={Button} 
                    variant="ghost" 
                    size="sm"
                  >
                    <IconFilter size={20} />
                  </MenuButton>
                </Menu>
              </Flex>
              <Stack spacing={4}>
                {alerts.map(alert => (
                  <Flex
                    key={alert.title}
                    p={4}
                    bg="gray.50"
                    borderRadius="xl"
                    justify="space-between"
                    align="center"
                  >
                    <Flex direction="column">
                      <Text fontWeight="medium">{alert.title}</Text>
                      <Text color="gray.500" fontSize="sm">
                        Due by {alert.deadline}
                      </Text>
                    </Flex>
                    <Badge
                      colorScheme={alert.severity === "high" ? "red" : "orange"}
                      borderRadius="full"
                    >
                      {alert.severity}
                    </Badge>
                  </Flex>
                ))}
              </Stack>
            </Flex>
          </Card>

          <Card>
            <Flex direction="column" p={6}>
              <Flex justify="space-between" align="center" mb={6}>
                <Text fontSize="lg" fontWeight="bold">Required Documents</Text>
                <Button size="sm" variant="ghost">
                  <IconUpload size={20} />
                </Button>
              </Flex>
              <Stack spacing={4}>
                {documents.map(doc => (
                  <Flex
                    key={doc.title}
                    p={4}
                    bg="gray.50"
                    borderRadius="xl"
                    justify="space-between"
                    align="center"
                  >
                    <Flex direction="column">
                      <Text fontWeight="medium">{doc.title}</Text>
                      <Text color="gray.500" fontSize="sm">
                        Due {doc.dueDate}
                      </Text>
                    </Flex>
                    <Badge
                      colorScheme={doc.status === "current" ? "green" : "yellow"}
                      borderRadius="full"
                    >
                      {doc.status}
                    </Badge>
                  </Flex>
                ))}
              </Stack>
            </Flex>
          </Card>
        </Grid>

        <Modal isOpen={isModalOpen} onClose={toggleModal}>
          <ModalOverlay />
          <ModalContent>
            <ModalHeader>Generate Compliance Report</ModalHeader>
            <ModalCloseButton />
            <ModalBody>
              <Stack spacing={4}>
                <FormControl>
                  <FormLabel>Report Type</FormLabel>
                  <Select>
                    <option value="ncaa">NCAA Compliance</option>
                    <option value="titleix">Title IX</option>
                  </Select>
                </FormControl>
                <FormControl>
                  <FormLabel>Date Range</FormLabel>
                  <Input type="date" />
                </FormControl>
              </Stack>
            </ModalBody>
            <ModalFooter>
              <Button onClick={toggleModal} variant="ghost">
                Cancel
              </Button>
              <Button>Generate</Button>
            </ModalFooter>
          </ModalContent>
        </Modal>
      </Flex>
    </ChakraProvider>
  );
};

export default ComplianceCenter;
