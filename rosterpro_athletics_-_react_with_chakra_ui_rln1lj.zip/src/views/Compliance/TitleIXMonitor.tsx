//@ts-nocheck

import React from 'react';
import { 
  ChakraProvider, 
  Flex, 
  Text, 
  Button, 
  Grid, 
  Card, 
  Badge, 
  Box, 
  Stack 
} from '@chakra-ui/react';
import { IconDownload } from '@tabler/icons-react';
import { kStyleGlobal } from '../../theme';
import { useNavigate } from 'react-router-dom';

const TitleIXMonitor: React.FC = () => {
  const navigate = useNavigate();
  const currentRatio = 0.42;
  const targetRatio = 0.5;

  const metrics = [
    {
      title: "Current Male/Female Ratio",
      value: "42/58",
      status: "warning",
      change: "-8%"
    },
    {
      title: "Scholarship Distribution",
      value: "45/55",
      status: "success",
      change: "+5%"
    },
    {
      title: "Participation Rate",
      value: "89%",
      status: "success",
      change: "+2.3%"
    }
  ];

  const actionItems = [
    {
      title: "Review Women's Soccer Roster",
      priority: "High",
      deadline: "Dec 15"
    },
    {
      title: "Adjust Track & Field Scholarships",
      priority: "Medium",
      deadline: "Jan 1"
    },
    {
      title: "Update Compliance Report",
      priority: "Low",
      deadline: "Jan 15"
    }
  ];

  return (
    <ChakraProvider theme={kStyleGlobal}>
      <Flex
        direction="column"
        p={8}
        gap={6}
      >
        <Flex
          justify="space-between"
          align="center"
          mb={2}
        >
          <Flex direction="column">
            <Text
              fontSize="2xl"
              fontWeight="bold"
            >
              Title IX Monitor
            </Text>
            <Text
              color="gray.500"
            >
              Track and manage gender equity compliance
            </Text>
          </Flex>
          <Button
            leftIcon={<IconDownload size={20} />}
            variant="secondary"
            onClick={() => navigate("/reports")}
          >
            Export Report
          </Button>
        </Flex>

        <Grid
          templateColumns={{
            base: "1fr",
            md: "repeat(3, 1fr)"
          }}
          gap={6}
        >
          {metrics.map((metric, index) => (
            <Card key={index}>
              <Flex
                direction="column"
                p={6}
              >
                <Flex
                  justify="space-between"
                  mb={4}
                >
                  <Text
                    color="gray.500"
                  >
                    {metric.title}
                  </Text>
                  <Badge
                    colorScheme={metric.status === "success" ? "green" : "yellow"}
                    borderRadius="full"
                  >
                    {metric.change}
                  </Badge>
                </Flex>
                <Text
                  fontSize="3xl"
                  fontWeight="bold"
                >
                  {metric.value}
                </Text>
              </Flex>
            </Card>
          ))}
        </Grid>

        <Grid
          templateColumns={{
            base: "1fr",
            lg: "2fr 1fr"
          }}
          gap={6}
        >
          <Card>
            <Flex
              direction="column"
              p={6}
            >
              <Flex
                justify="space-between"
                align="center"
                mb={6}
              >
                <Text
                  fontSize="lg"
                  fontWeight="bold"
                >
                  Gender Equity Progress
                </Text>
                <Button
                  size="sm"
                  variant="ghost"
                >
                  View Details
                </Button>
              </Flex>
              <Box
                h="300px"
                bg="gray.50"
                borderRadius="xl"
                mb={4}
              />
              <Flex
                gap={4}
                wrap="wrap"
              >
                <Badge
                  bg="green.100"
                  color="green.700"
                  borderRadius="full"
                  px={3}
                  py={1}
                >
                  On Track
                </Badge>
                <Badge
                  bg="yellow.100"
                  color="yellow.700"
                  borderRadius="full"
                  px={3}
                  py={1}
                >
                  Needs Attention
                </Badge>
                <Badge
                  bg="red.100"
                  color="red.700"
                  borderRadius="full"
                  px={3}
                  py={1}
                >
                  Non-Compliant
                </Badge>
              </Flex>
            </Flex>
          </Card>

          <Card>
            <Flex
              direction="column"
              p={6}
            >
              <Flex
                justify="space-between"
                align="center"
                mb={6}
              >
                <Text
                  fontSize="lg"
                  fontWeight="bold"
                >
                  Action Items
                </Text>
                <Button
                  size="sm"
                  variant="ghost"
                >
                  View All
                </Button>
              </Flex>
              <Stack spacing={4}>
                {actionItems.map((item, index) => (
                  <Flex
                    key={index}
                    bg="gray.50"
                    p={4}
                    borderRadius="xl"
                    justify="space-between"
                    align="center"
                  >
                    <Flex direction="column">
                      <Text
                        fontWeight="medium"
                      >
                        {item.title}
                      </Text>
                      <Text
                        fontSize="sm"
                        color="gray.500"
                      >
                        {`Due ${item.deadline}`}
                      </Text>
                    </Flex>
                    <Badge
                      colorScheme={
                        item.priority === "High" 
                          ? "red" 
                          : item.priority === "Medium" 
                            ? "yellow" 
                            : "green"
                      }
                      borderRadius="full"
                    >
                      {item.priority}
                    </Badge>
                  </Flex>
                ))}
              </Stack>
            </Flex>
          </Card>
        </Grid>
      </Flex>
    </ChakraProvider>
  );
};

export default TitleIXMonitor;
