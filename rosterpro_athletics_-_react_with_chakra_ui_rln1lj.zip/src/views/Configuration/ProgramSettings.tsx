//@ts-nocheck

import React, { useState } from 'react';
import { 
  ChakraProvider, 
  Container, 
  Flex, 
  Text, 
  Button, 
  Tabs, 
  TabList, 
  Tab, 
  Grid, 
  Card, 
  FormControl, 
  FormLabel, 
  Input, 
  Select, 
  RadioGroup, 
  Stack, 
  Radio, 
  Modal, 
  ModalOverlay, 
  ModalContent, 
  ModalHeader, 
  ModalCloseButton, 
  ModalBody, 
  Switch 
} from '@chakra-ui/react';
import { 
  IconSettings, 
  IconBuilding, 
  IconCalendarEvent, 
  IconUsers, 
  IconShieldCheck, 
  IconBuildingUniversity, 
  IconUpload, 
  IconCalendar, 
  IconAward, 
  IconDeviceFloppy 
} from '@tabler/icons-react';
import { kStyleGlobal } from '../../theme';

const ProgramSettings = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState("program");
  const [selectedGroup, setSelectedGroup] = useState(null);

  const toggleModal = () => {
    setIsModalOpen(!isModalOpen);
  };

  return (
    <ChakraProvider theme={kStyleGlobal}>
      <Container maxW={"1200px"} mx={"auto"} p={8}>
        <Flex justify={"space-between"} mb={8} align={"center"}>
          <Flex direction={"column"}>
            <Text fontSize={"2xl"} fontWeight={"bold"}>
              Program Settings
            </Text>
            <Text color={"gray.500"}>
              Configure your program's core settings and preferences
            </Text>
          </Flex>
          <Button onClick={toggleModal}>
            <IconSettings size={20} />
            <Text ml={2}>Quick Settings</Text>
          </Button>
        </Flex>

        <Tabs mb={6}>
          <TabList>
            <Tab 
              isSelected={activeTab === "program"} 
              onClick={() => setActiveTab("program")}
            >
              <IconBuilding size={20} />
              <Text ml={2}>Program Info</Text>
            </Tab>
            <Tab 
              isSelected={activeTab === "events"} 
              onClick={() => setActiveTab("events")}
            >
              <IconCalendarEvent size={20} />
              <Text ml={2}>Events</Text>
            </Tab>
            <Tab 
              isSelected={activeTab === "roster"} 
              onClick={() => setActiveTab("roster")}
            >
              <IconUsers size={20} />
              <Text ml={2}>Roster</Text>
            </Tab>
            <Tab 
              isSelected={activeTab === "compliance"} 
              onClick={() => setActiveTab("compliance")}
            >
              <IconShieldCheck size={20} />
              <Text ml={2}>Compliance</Text>
            </Tab>
          </TabList>
        </Tabs>

        <Grid templateColumns={"repeat(3, 1fr)"} gap={6}>
          <Card>
            <Flex direction={"column"} gap={4}>
              <Flex align={"center"} gap={2}>
                <IconBuildingUniversity size={24} color={"primary.500"} />
                <Text fontSize={"lg"} fontWeight={"semibold"}>
                  Institution Details
                </Text>
              </Flex>
              <FormControl>
                <FormLabel>University Name</FormLabel>
                <Input placeholder={"Enter university name"} />
              </FormControl>
              <FormControl>
                <FormLabel>Division Level</FormLabel>
                <Select>
                  <option value={"1"}>Division I</option>
                  <option value={"2"}>Division II</option>
                  <option value={"3"}>Division III</option>
                </Select>
              </FormControl>
              <Button 
                variant={"outline"} 
                leftIcon={<IconUpload size={20} />}
              >
                Upload Logo
              </Button>
            </Flex>
          </Card>

          <Card>
            <Flex direction={"column"} gap={4}>
              <Flex align={"center"} gap={2}>
                <IconCalendar size={24} color={"primary.500"} />
                <Text fontSize={"lg"} fontWeight={"semibold"}>
                  Academic Calendar
                </Text>
              </Flex>
              <RadioGroup>
                <Stack>
                  <Radio value={"semester"}>Semester System</Radio>
                  <Radio value={"quarter"}>Quarter System</Radio>
                </Stack>
              </RadioGroup>
              <FormControl>
                <FormLabel>Academic Year Start</FormLabel>
                <Input type={"date"} />
              </FormControl>
            </Flex>
          </Card>

          <Card>
            <Flex direction={"column"} gap={4}>
              <Flex align=