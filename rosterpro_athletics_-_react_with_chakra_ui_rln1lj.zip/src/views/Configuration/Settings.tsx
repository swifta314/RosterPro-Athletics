//@ts-nocheck

import React, { useState } from 'react';
import { 
  ChakraProvider, 
  Container, 
  Breadcrumb, 
  BreadcrumbItem, 
  Flex, 
  Box, 
  Heading, 
  Text, 
  Tabs, 
  TabList, 
  Tab, 
  Grid, 
  GridItem, 
  Card, 
  CardHeader, 
  CardBody, 
  Stack, 
  FormControl, 
  FormLabel, 
  Input, 
  Select, 
  Badge, 
  Button, 
  Stat, 
  StatLabel, 
  StatNumber 
} from '@chakra-ui/react';
import { useNavigate } from 'react-router-dom';
import { kStyleGlobal } from '../../theme';

const Settings: React.FC = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedTab, setSelectedTab] = useState("General");
  const navigate = useNavigate();

  const tabs = ["General", "Users", "Notifications", "Integrations"];
  const integrations = [
    {
      "name": "Student Information System",
      "status": "Connected",
      "lastSync": "2 hours ago"
    },
    {
      "name": "Financial Aid",
      "status": "Disconnected",
      "lastSync": "Never"
    }
  ];

  const toggleModal = () => {
    setIsModalOpen(!isModalOpen);
  };

  return (
    <ChakraProvider theme={kStyleGlobal}>
      <Container maxW={"1200px"} mx={"auto"} p={8}>
        <Breadcrumb mb={6}>
          <BreadcrumbItem>
            <Text>Dashboard</Text>
          </BreadcrumbItem>
          <BreadcrumbItem isCurrentPage={true}>
            <Text>Settings</Text>
          </BreadcrumbItem>
        </Breadcrumb>
        
        <Flex justify={"space-between"} mb={8} align={"center"}>
          <Box>
            <Heading mb={2}>
              <Text>Settings</Text>
            </Heading>
            <Text color={"gray.600"}>
              Configure your program settings and preferences
            </Text>
          </Box>
        </Flex>
        
        <Tabs mb={6}>
          <TabList>
            {tabs.map(tab => (
              <Tab 
                key={tab} 
                onClick={() => setSelectedTab(tab)}
              >
                <Text>{tab}</Text>
              </Tab>
            ))}
          </TabList>
        </Tabs>
        
        <Grid templateColumns={"repeat(12, 1fr)"} gap={6}>
          <GridItem colSpan={{base: 12, md: 8}}>
            <Card mb={6}>
              <CardHeader>
                <Text fontWeight={"bold"}>Program Information</Text>
              </CardHeader>
              <CardBody>
                <Stack spacing={4}>
                  <FormControl>
                    <FormLabel>
                      <Text>Program Name</Text>
                    </FormLabel>
                    <Input placeholder={"Enter program name"} />
                  </FormControl>
                  <FormControl>
                    <FormLabel>
                      <Text>University</Text>
                    </FormLabel>
                    <Input placeholder={"Enter university name"} />
                  </FormControl>
                  <Grid templateColumns={"repeat(2, 1fr)"} gap={4}>
                    <FormControl>
                      <FormLabel>
                        <Text>Division</Text>
                      </FormLabel>
                      <Select>
                        <option value={"d1"}>Division I</option>
                        <option value={"d2"}>Division II</option>
                      </Select>
                    </FormControl>
                    <FormControl>
                      <FormLabel>
                        <Text>Conference</Text>
                      </FormLabel>
                      <Select>
                        <option value={"acc"}>ACC</option>
                        <option value={"big10"}>Big 10</option>
                      </Select>
                    </FormControl>
                  </Grid>
                </Stack>
              </CardBody>
            </Card>
            
            <Card>
              <CardHeader>
                <Text fontWeight={"bold"}>System Integrations</Text>
              </CardHeader>
              <CardBody>
                <Stack spacing={4}>
                  {integrations.map(integration => (
                    <Flex 
                      key={integration.name}
                      justify={"space-between"}
                      align={"center"}
                      p={4}
                      bg={"gray.50"}
                      borderRadius={"xl"}
                    >
                      <Stack>
                        <Text fontWeight={"medium"}>{integration.name}</Text>
                        <Flex align={"center"} gap={2}>
                          <Badge 
                            colorScheme={integration.status === "Connected" ? "green" : "red"}
                          >
                            {integration.status}
                          </Badge>
                          <Text 
                            fontSize={"sm"} 
                            color={"gray.500"}
                          >
                            {`Last sync: ${integration.lastSync}`}
                          </Text>
                        </Flex>
                      </Stack>
                      <Button 
                        variant={"secondary"} 
                        onClick={toggleModal}
                      >
                        {integration.status === "Connected" ? "Configure" : "Connect"}
                      </Button>
                    </Flex>
                  ))}
                </Stack>
              </CardBody>
            </Card>
          </GridItem>
          
          <GridItem colSpan={{base: 12, md: 4}}>
            <Card mb={6}>
              <CardHeader>
                <Text fontWeight={"bold"}>User Management</Text>
              </CardHeader>
              <CardBody>
                <Stack spacing={4}>
                  <Stat>
                    <StatLabel>
                      <Text>Total Users</Text>
                    </StatLabel>
                    <StatNumber>
                      <Text>156</Text>
                    </StatNumber>
                  </Stat>
                  <Button 
                    onClick={() => navigate("/user-management")} 
                    width={"full"}
                  >
                    Manage Users
                  </Button>
                </Stack>
              </CardBody>
            </Card>
            
            <Card>
              <CardHeader>
                <Text fontWeight={"bold"}>Recent Activity</Text>
              </CardHeader>
              <CardBody>
                <Stack>
                  <Box>
                    <Text>New user added</Text>
                    <Text color={"gray.500"} fontSize={"sm"}>
                      2 hours ago
                    </Text>
                  </Box>
                  <Box>
                    <Text>Settings updated</Text>
                    <Text color={"gray.500"} fontSize={"sm"}>
                      1 day ago
                    </Text>
                  </Box>
                </Stack>
              </CardBody>
            </Card>
          </GridItem>
        </Grid>
      </Container>
    </ChakraProvider>
  );
};

export default Settings;
