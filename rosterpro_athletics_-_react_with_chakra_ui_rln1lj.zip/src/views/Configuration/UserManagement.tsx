//@ts-nocheck

import React, { useState } from 'react';
import { 
  Box, 
  Flex, 
  Text, 
  Button, 
  Card, 
  InputGroup, 
  InputLeftElement, 
  Input, 
  Menu, 
  MenuButton, 
  Table, 
  Thead, 
  Tbody, 
  Tr, 
  Th, 
  Td, 
  Checkbox, 
  Badge, 
  IconButton, 
  Modal, 
  ModalOverlay, 
  ModalContent, 
  ModalHeader, 
  ModalBody, 
  ModalFooter, 
  FormControl, 
  FormLabel, 
  Select, 
  Stack 
} from '@chakra-ui/react';
import { 
  IconChevronRight, 
  IconUserPlus, 
  IconSearch, 
  IconFilter, 
  IconDots, 
  IconEdit, 
  IconTrash 
} from '@tabler/icons-react';
import { ChakraProvider } from '@chakra-ui/react';
import { kStyleGlobal } from '../../theme';

const UserManagement = () => {
  const [isAddUserModalOpen, setIsAddUserModalOpen] = useState(false);
  const [isRoleManagementOpen, setIsRoleManagementOpen] = useState(false);
  const [selectedUsers, setSelectedUsers] = useState([]);
  const [searchQuery, setSearchQuery] = useState("");
  const [users, setUsers] = useState([
    {
      "name": "John Smith",
      "email": "john.smith@rosterpro.com",
      "role": "Head Coach",
      "department": "Football",
      "status": "Active"
    },
    {
      "name": "Sarah Wilson",
      "email": "sarah.wilson@rosterpro.com",
      "role": "Assistant Coach",
      "department": "Basketball",
      "status": "Active"
    },
    {
      "name": "Mike Johnson",
      "email": "mike.j@rosterpro.com",
      "role": "Compliance Officer",
      "department": "Athletics",
      "status": "Inactive"
    }
  ]);

  const toggleAddUserModal = () => {
    setIsAddUserModalOpen(!isAddUserModalOpen);
  };

  const toggleRoleManagement = () => {
    setIsRoleManagementOpen(!isRoleManagementOpen);
  };

  return (
    <ChakraProvider theme={kStyleGlobal}>
      <Box
        p={6}
        bg={"background"}
        minH={"100vh"}
      >
        <Flex
          justify={"space-between"}
          mb={6}
          align={"center"}
        >
          <Flex direction={"column"}>
            <Text
              fontSize={"2xl"}
              fontWeight={"bold"}
            >
              User Management
            </Text>
            <Flex
              align={"center"}
              gap={2}
              color={"gray.500"}
            >
              <Text>Settings</Text>
              <IconChevronRight size={16} />
              <Text>User Management</Text>
            </Flex>
          </Flex>
          <Button onClick={toggleAddUserModal}>
            <Flex
              align={"center"}
              gap={2}
            >
              <IconUserPlus size={20} />
              <Text>Add User</Text>
            </Flex>
          </Button>
        </Flex>
        <Card mb={6}>
          <Flex
            justify={"space-between"}
            mb={4}
            align={"center"}
          >
            <InputGroup maxW={"320px"}>
              <InputLeftElement>
                <IconSearch size={20} color={"gray.400"} />
              </InputLeftElement>
              <Input
                placeholder={"Search users..."}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </InputGroup>
            <Flex gap={3}>
              <Menu>
                <MenuButton
                  as={Button}
                  variant={"outline"}
                >
                  <Flex
                    align={"center"}
                    gap={2}
                  >
                    <IconFilter size={20} />
                    <Text>Filters</Text>
                  </Flex>
                </MenuButton>
              </Menu>
              <Button
                variant={"outline"}
                isDisabled={selectedUsers.length === 0}
              >
                <Flex
                  align={"center"}
                  gap={2}
                >
                  <IconDots size={20} />
                  <Text>Bulk Actions</Text>
                </Flex>
              </Button>
            </Flex>
          </Flex>
          <Table>
            <Thead>
              <Tr>
                <Th w=