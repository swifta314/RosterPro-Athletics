//@ts-nocheck

import React, { useState } from 'react';
import { 
  ChakraProvider, 
  Flex, 
  Box, 
  Button, 
  IconButton, 
  Text, 
  InputGroup, 
  InputLeftElement, 
  Input, 
  Avatar 
} from '@chakra-ui/react';
import { 
  IconTrophy, 
  IconX, 
  IconDashboard, 
  IconCalendarTime, 
  IconTimeline, 
  IconUser, 
  IconCoin, 
  IconChartLine, 
  IconClipboardCheck, 
  IconTransfer, 
  IconReportAnalytics, 
  IconSettings, 
  IconLogout, 
  IconMenu, 
  IconSearch, 
  IconBell 
} from '@tabler/icons-react';
import { useRouter } from 'next/router';
import { kStyleGlobal } from '../theme';

const SidebarLayout: React.FC = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const router = useRouter();
  const path = router.asPath || "/";

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const navigateTo = (route: string) => {
    router.push(route);
  };

  const renderNavButton = (
    label: string, 
    route: string, 
    Icon: React.ElementType
  ) => (
    <Button
      onClick={() => navigateTo(route)}
      bg={path.includes(route) ? "gray.100" : "transparent"}
      variant="ghost"
      h="56px"
      borderRadius="xl"
      leftIcon={<Icon size={22} />}
      color={path.includes(route) ? "primary.500" : "inherit"}
      _hover={{
        bg: "gray.100",
        color: "primary.500"
      }}
    >
      <Text>{label}</Text>
    </Button>
  );

  return (
    <ChakraProvider theme={kStyleGlobal}>
      <Flex 
        bg="background"
        minH="100vh"
      >
        <Flex
          direction="column"
          h="100vh"
          w={{
            base: "full",
            lg: "280px"
          }}
          position="fixed"
          bg="white"
          borderRight="1px"
          borderColor="borderColor"
          zIndex={20}
          transform={{
            base: isMobileMenuOpen ? "translateX(0)" : "translateX(-100%)",
            lg: "translateX(0)"
          }}
          transition="transform 0.3s"
        >
          <Flex
            p={6}
            direction="column"
            h="full"
          >
            <Flex
              align="center"
              mb={8}
              justify="space-between"
            >
              <Flex align="center">
                <Box
                  bg="primary.500"
                  p={2.5}
                  borderRadius="2xl"
                >
                  <IconTrophy size={28} color="white" />
                </Box>
                <Text
                  fontSize="22px"
                  fontWeight="bold"
                  marginLeft="12px"
                >
                  RosterPro
                </Text>
              </Flex>
              {isMobileMenuOpen && (
                <IconButton
                  variant="ghost"
                  icon={<IconX size={24} />}
                  onClick={toggleMobileMenu}
                  _hover={{
                    bg: "gray.100"
                  }}
                  aria-label="Close mobile menu"
                />
              )}
            </Flex>
            <Flex
              direction="column"
              gap={2}
              flex={1}
            >
              {renderNavButton("Dashboard", "/dashboard", IconDashboard)}
              {renderNavButton("Multi-Year Planner", "/roster-planner", IconCalendarTime)}
              {renderNavButton("Roster Timeline", "/roster-timeline", IconTimeline)}
              {renderNavButton("Athletes", "/athlete-details", IconUser)}
              {renderNavButton("Scholarships", "/scholarship-tracker", IconCoin)}
              {renderNavButton("Performance", "/performance", IconChartLine)}
              {renderNavButton("Compliance", "/compliance", IconClipboardCheck)}
              {renderNavButton("Transfer Portal", "/transfer-portal", IconTransfer)}
              {renderNavButton("Reports", "/reports", IconReportAnalytics)}
              {renderNavButton("Settings", "/settings", IconSettings)}
            </Flex>
            <Button
              variant="ghost"
              h="56px"
              borderRadius="xl"
              leftIcon={<IconLogout size={22} />}
              onClick={() => navigateTo("/login")}
              _hover={{
                bg: "gray.100"
              }}
            >
              <Text color="red.500">Logout</Text>
            </Button>
          </Flex>
        </Flex>
        <Flex
          flex={1}
          ml={{
            base: 0,
            lg: "280px"
          }}
          direction="column"
        >
          <Flex
            position="sticky"
            top={0}
            bg="white"
            borderBottom="1px"
            borderColor="borderColor"
            px={6}
            py={4}
            align="center"
            justify="space-between"
            zIndex={10}
          >
            <Flex
              align="center"
              gap={4}
            >
              <IconButton
                variant="ghost"
                onClick={toggleMobileMenu}
                display={{
                  base: "flex",
                  lg: "none"
                }}
                icon={<IconMenu size={24} />}
                aria-label="Toggle mobile menu"
              />
              <Text
                fontSize="xl"
                fontWeight="bold"
              >
                RosterPro Athletics
              </Text>
            </Flex>
            <Flex
              gap={4}
              align="center"
            >
              <InputGroup
                display={{
                  base: "none",
                  md: "flex"
                }}
                maxW="320px"
              >
                <InputLeftElement>
                  <IconSearch size={20} color="gray.400" />
                </InputLeftElement>
                <Input
                  placeholder="Search athletes..."
                  bg="gray.50"
                  border="none"
                />
              </InputGroup>
              <IconButton
                variant="ghost"
                icon={<IconBell size={22} />}
                aria-label="Notifications"
              />
              <Avatar
                size="sm"
                src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e"
                cursor="pointer"
                onClick={() => navigateTo("/settings")}
              />
            </Flex>
          </Flex>
          <Box p={6}>
            {/* Dynamic content will be rendered here */}
          </Box>
        </Flex>
      </Flex>
    </ChakraProvider>
  );
};

export default SidebarLayout;
