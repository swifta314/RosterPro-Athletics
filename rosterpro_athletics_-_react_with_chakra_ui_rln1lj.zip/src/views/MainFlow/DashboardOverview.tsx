//@ts-nocheck

import React from 'react';
import { 
  ChakraProvider, 
  Container, 
  Flex, 
  Grid, 
  Card, 
  Badge, 
  Box, 
  Stack, 
  Avatar, 
  Button 
} from '@chakra-ui/react';
import { 
  IconUsers, 
  IconWallet, 
  IconUserPlus, 
  IconClipboardCheck,
  IconAlertTriangle,
  IconClipboardList,
  IconTrophy 
} from '@tabler/icons-react';
import { Text } from '@chakra-ui/react';
import Chart from 'react-apexcharts';
import { kStyleGlobal } from '../../theme';
import { useNavigate } from 'react-router-dom';

const DashboardOverview: React.FC = () => {
  const navigate = useNavigate();

  const quickStats = [
    {
      "title": "Total Athletes",
      "value": "156",
      "change": "+12%",
      "trend": "up",
      "icon": IconUsers
    },
    {
      "title": "Scholarship Budget",
      "value": "$2.4M",
      "change": "-8%",
      "trend": "down",
      "icon": IconWallet
    },
    {
      "title": "Roster Spots",
      "value": "24",
      "change": "+4",
      "trend": "up",
      "icon": IconUserPlus
    },
    {
      "title": "Compliance Tasks",
      "value": "12",
      "change": "3 urgent",
      "trend": "warning",
      "icon": IconClipboardCheck
    }
  ];

  const rosterBreakdown = [
    { "group": "Sprints", "count": 45 },
    { "group": "Distance", "count": 32 },
    { "group": "Throws", "count": 28 },
    { "group": "Jumps", "count": 25 }
  ];

  const recentPerformances = [
    {
      "athlete": "Sarah Johnson",
      "event": "100m",
      "performance": "11.2s",
      "date": "Oct 15",
      "image": "https://images.unsplash.com/photo-1552674605-db6ffd4facb5"
    },
    {
      "athlete": "Mike Thompson",
      "event": "Shot Put",
      "performance": "18.5m",
      "date": "Oct 14",
      "image": "https://images.unsplash.com/photo-1461896836934-ffe607ba8211"
    }
  ];

  return (
    <ChakraProvider theme={kStyleGlobal}>
      <Container maxW="7xl" px={4} py={8}>
        <Flex direction="column" gap={8}>
          <Grid 
            templateColumns={{
              "base": "1fr",
              "md": "repeat(4, 1fr)"
            }}
            gap={6}
          >
            {quickStats.map((stat, index) => (
              <Card key={index} p={4}>
                <Flex align="center" justify="space-between" mb={4}>
                  <stat.icon 
                    size={24} 
                    color={kStyleGlobal.colors.primary[500]} 
                  />
                  <Badge 
                    colorScheme={
                      stat.trend === "up" ? "green" : 
                      stat.trend === "down" ? "red" : "orange"
                    } 
                    borderRadius="full"
                  >
                    {stat.change}
                  </Badge>
                </Flex>
                <Text 
                  color="gray.600" 
                  fontSize="sm" 
                  mb={1}
                >
                  {stat.title}
                </Text>
                <Text 
                  fontSize="2xl" 
                  fontWeight="bold"
                >
                  {stat.value}
                </Text>
              </Card>
            ))}
          </Grid>

          <Grid
            templateColumns={{
              "base": "1fr",
              "lg": "2fr 1fr"
            }}
            gap={6}
          >
            <Card p={6}>
              <Flex justify="space-between" mb={6}>
                <Text fontSize="lg" fontWeight="bold">
                  Roster Distribution
                </Text>
                <Button 
                  variant="ghost" 
                  onClick={() => navigate("/roster-planner")}
                >
                  View Details
                </Button>
              </Flex>
              <Flex gap={8}>
                <Chart
                  type="pie"
                  height={240}
                  series={rosterBreakdown.map((item) => item.count)}
                  options={{
                    labels: rosterBreakdown.map((item) => item.group),
                    colors: [
                      kStyleGlobal.colors.primary[500],
                      kStyleGlobal.colors.primary[400],
                      kStyleGlobal.colors.primary[300],
                      kStyleGlobal.colors.primary[200]
                    ]
                  }}
                />
                <Stack spacing={4}>
                  {rosterBreakdown.map((item, index) => (
                    <Flex key={index} justify="space-between" align="center">
                      <Flex align="center" gap={2}>
                        <Box 
                          w={3} 
                          h={3} 
                          borderRadius="full" 
                          bg="primary.500" 
                        />
                        <Text>{item.group}</Text>
                      </Flex>
                      <Text fontWeight="medium">
                        {item.count}
                      </Text>
                    </Flex>
                  ))}
                </Stack>
              </Flex>
            </Card>

            <Card p={6}>
              <Flex justify="space-between" mb={6}>
                <Text fontSize="lg" fontWeight="bold">
                  Recent Performances
                </Text>
                <Button 
                  variant="ghost" 
                  onClick={() => navigate("/performance")}
                >
                  See All
                </Button>
              </Flex>
              <Stack spacing={4}>
                {recentPerformances.map((perf, index) => (
                  <Flex key={index} gap={4} align="center">
                    <Avatar src={perf.image} size="md" />
                    <Flex flex={1}>
                      <Text fontWeight="medium">
                        {perf.athlete}
                      </Text>
                      <Flex justify="space-between">
                        <Text fontSize="sm" color="gray.600">
                          {perf.event}
                        </Text>
                        <Text fontWeight="bold" color="primary.500">
                          {perf.performance}
                        </Text>
                      </Flex>
                    </Flex>
                    <Text fontSize="sm" color="gray.500">
                      {perf.date}
                    </Text>
                  </Flex>
                ))}
              </Stack>
            </Card>
          </Grid>

          <Card p={6}>
            <Flex justify="space-between" mb={6}>
              <Text fontSize="lg" fontWeight="bold">
                Action Center
              </Text>
              <Button variant="ghost">
                Clear All
              </Button>
            </Flex>
            <Grid
              templateColumns={{
                "base": "1fr",
                "md": "repeat(3, 1fr)"
              }}
              gap={4}
            >
              <Card bg="orange.50" borderColor="orange.200" p={4}>
                <Flex align="center" gap={3}>
                  <IconAlertTriangle 
                    size={24} 
                    color={kStyleGlobal.colors.warning} 
                  />
                  <Flex flex={1}>
                    <Text fontWeight="medium">
                      Compliance Deadline
                    </Text>
                    <Text fontSize="sm" color="gray.600">
                      2 forms due tomorrow
                    </Text>
                  </Flex>
                </Flex>
              </Card>
              <Card bg="blue.50" borderColor="blue.200" p={4}>
                <Flex align="center" gap={3}>
                  <IconClipboardList 
                    size={24} 
                    color={kStyleGlobal.colors.info} 
                  />
                  <Flex flex={1}>
                    <Text fontWeight="medium">
                      Roster Review
                    </Text>
                    <Text fontSize="sm" color="gray.600">
                      Spring semester planning
                    </Text>
                  </Flex>
                </Flex>
              </Card>
              <Card bg="green.50" borderColor="green.200" p={4}>
                <Flex align="center" gap={3}>
                  <IconTrophy 
                    size={24} 
                    color={kStyleGlobal.colors.success} 
                  />
                  <Flex flex={1}>
                    <Text fontWeight="medium">
                      Performance Update
                    </Text>
                    <Text fontSize="sm" color="gray.600">
                      3 new season bests
                    </Text>
                  </Flex>
                </Flex>
              </Card>
            </Grid>
          </Card>
        </Flex>
      </Container>
    </ChakraProvider>
  );
};

export default DashboardOverview;
