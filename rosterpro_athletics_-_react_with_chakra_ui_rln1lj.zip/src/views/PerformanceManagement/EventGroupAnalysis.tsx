//@ts-nocheck

import React, { useState } from 'react';
import { 
  ChakraProvider, 
  Flex, 
  Button, 
  Text, 
  Grid, 
  Card, 
  Badge, 
  Stat, 
  Box, 
  Stack, 
  Modal, 
  ModalOverlay, 
  ModalContent, 
  ModalHeader, 
  ModalBody, 
  ModalFooter, 
  FormControl, 
  FormLabel, 
  Select, 
  RadioGroup, 
  Radio 
} from '@chakra-ui/react';
import { IconArrowLeft, IconFilter, IconShare, IconInfoCircle } from '@tabler/icons-react';
import { kStyleGlobal } from '../theme';
import { useNavigate } from 'react-router-dom';

const EventGroupAnalysis: React.FC = () => {
  const [selectedGroup, setSelectedGroup] = useState("Sprints");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const navigate = useNavigate();

  const eventGroups = ["Sprints", "Distance", "Throws", "Jumps", "Combined Events"];
  const performanceData = {
    totalAthletes: 45,
    scholarshipAllocation: "$850,000",
    pointsScored: 234
  };
  const athleteDistribution = {
    "FR": 12,
    "SO": 15,
    "JR": 10,
    "SR": 8
  };
  const performanceTiers = {
    "Elite": 8,
    "A": 15,
    "B": 12,
    "C": 10
  };

  const toggleModal = () => {
    setIsModalOpen(!isModalOpen);
  };

  return (
    <ChakraProvider theme={kStyleGlobal}>
      <Flex
        direction="column"
        p={6}
        bg="background"
        minH="100vh"
      >
        <Flex
          justify="space-between"
          mb={8}
          align="center"
        >
          <Flex direction="column">
            <Flex
              align="center"
              gap={2}
              mb={2}
            >
              <Button
                variant="ghost"
                onClick={() => navigate("/performance")}
              >
                <IconArrowLeft size={20} />
              </Button>
              <Text
                fontSize="24px"
                fontWeight="bold"
              >
                Event Group Analysis
              </Text>
            </Flex>
            <Flex
              gap={2}
              mt={2}
            >
              {eventGroups.map(group => (
                <Button
                  key={group}
                  variant={selectedGroup === group ? "primary" : "ghost"}
                  size="sm"
                >
                  <Text>{group}</Text>
                </Button>
              ))}
            </Flex>
          </Flex>
          <Flex gap={4}>
            <Button
              variant="ghost"
              onClick={toggleModal}
            >
              <IconFilter size={20} />
            </Button>
            <Button variant="ghost">
              <IconShare size={20} />
            </Button>
          </Flex>
        </Flex>
        <Grid
          templateColumns={{
            base: "1fr",
            md: "2fr 1fr"
          }}
          gap={6}
        >
          <Flex
            direction="column"
            gap={6}
          >
            <Card>
              <Flex
                justify="space-between"
                mb={6}
              >
                <Flex direction="column">
                  <Text
                    fontSize="18px"
                    fontWeight="600"
                    marginBottom={2}
                  >
                    Performance Overview
                  </Text>
                  <Text color="gray.500">
                    Year-over-year metrics and rankings
                  </Text>
                </Flex>
                <Badge
                  colorScheme="primary"
                  variant="subtle"
                >
                  <Text>2023-24 Season</Text>
                </Badge>
              </Flex>
              <Grid
                templateColumns={{
                  base: "1fr",
                  md: "repeat(3, 1fr)"
                }}
                gap={4}
                mb={6}
              >
                <Stat>
                  <Text
                    color="gray.500"
                    fontSize="14px"
                  >
                    Total Athletes
                  </Text>
                  <Text
                    fontSize="24px"
                    fontWeight="bold"
                  >
                    {performanceData.totalAthletes}
                  </Text>
                </Stat>
                <Stat>
                  <Text
                    color="gray.500"
                    fontSize="14px"
                  >
                    Scholarship Allocation
                  </Text>
                  <Text
                    fontSize="24px"
                    fontWeight="bold"
                  >
                    {performanceData.scholarshipAllocation}
                  </Text>
                </Stat>
                <Stat>
                  <Text
                    color="gray.500"
                    fontSize="14px"
                  >
                    Points Scored
                  </Text>
                  <Text
                    fontSize="24px"
                    fontWeight="bold"
                  >
                    {performanceData.pointsScored}
                  </Text>
                </Stat>
              </Grid>
              <Box
                bg="gray.50"
                p={4}
                borderRadius="xl"
                h="200px"
                mb={4}
              >
                <Text color="gray.500">
                  Performance Trend Graph
                </Text>
              </Box>
            </Card>
            <Card>
              <Text
                fontSize="18px"
                fontWeight="600"
                marginBottom={4}
              >
                Athlete Distribution
              </Text>
              <Grid
                templateColumns={{
                  base: "1fr",
                  md: "repeat(2, 1fr)"
                }}
                gap={6}
              >
                <Box>
                  <Text
                    fontWeight="500"
                    marginBottom={4}
                  >
                    By Academic Year
                  </Text>
                  <Flex
                    direction="column"
                    gap={2}
                  >
                    {Object.entries(athleteDistribution).map(([year, count]) => (
                      <Flex
                        key={year}
                        justify="space-between"
                        align="center"
                      >
                        <Text>{year}</Text>
                        <Text fontWeight="500">{count}</Text>
                      </Flex>
                    ))}
                  </Flex>
                </Box>
                <Box>
                  <Text
                    fontWeight="500"
                    marginBottom={4}
                  >
                    Performance Tiers
                  </Text>
                  <Flex
                    direction="column"
                    gap={2}
                  >
                    {Object.entries(performanceTiers).map(([tier, count]) => (
                      <Flex
                        key={tier}
                        justify="space-between"
                        align="center"
                      >
                        <Text>{tier}</Text>
                        <Text fontWeight="500">{count}</Text>
                      </Flex>
                    ))}
                  </Flex>
                </Box>
              </Grid>
            </Card>
          </Flex>
          <Flex
            direction="column"
            gap={6}
          >
            <Card>
              <Flex
                justify="space-between"
                align="center"
                mb={4}
              >
                <Text
                  fontSize="18px"
                  fontWeight="600"
                >
                  Development Tracking
                </Text>
                <Button
                  size="sm"
                  variant="ghost"
                >
                  <Text>View All</Text>
                </Button>
              </Flex>
              <Stack spacing={4}>
                <Flex
                  direction="column"
                  p={4}
                  bg="gray.50"
                  borderRadius="xl"
                >
                  <Text
                    fontWeight="500"
                    marginBottom={2}
                  >
                    Group Progress
                  </Text>
                  {/* Progress component would be added here */}
                </Flex>
              </Stack>
            </Card>
            <Card>
              <Flex
                justify="space-between"
                align="center"
                mb={4}
              >
                <Text
                  fontSize="18px"
                  fontWeight="600"
                >
                  Compliance Status
                </Text>
                <IconInfoCircle size={20} color="gray.400" />
              </Flex>
              <Stack spacing={4}>
                <Flex
                  justify="space-between"
                  align="center"
                >
                  <Text>Practice Hours</Text>
                  <Badge colorScheme="green">
                    <Text>Compliant</Text>
                  </Badge>
                </Flex>
                <Flex
                  justify="space-between"
                  align="center"
                >
                  <Text>Title IX Status</Text>
                  <Badge colorScheme="green">
                    <Text>Compliant</Text>
                  </Badge>
                </Flex>
              </Stack>
            </Card>
          </Flex>
        </Grid>
      </Flex>
      <Modal
        isOpen={isModalOpen}
        onClose={toggleModal}
      >
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>
            <Text>Filter Options</Text>
          </ModalHeader>
          <ModalBody>
            <Stack spacing={4}>
              <FormControl>
                <FormLabel>
                  <Text>Academic Year</Text>
                </FormLabel>
                <Select>
                  <option value="2023">2023-24</option>
                </Select>
              </FormControl>
              <FormControl>
                <FormLabel>
                  <Text>Season</Text>
                </FormLabel>
                <RadioGroup>
                  <Stack>
                    <Radio value="indoor">
                      <Text>Indoor</Text>
                    </Radio>
                    <Radio value="outdoor">
                      <Text>Outdoor</Text>
                    </Radio>
                  </Stack>
                </RadioGroup>
              </FormControl>
            </Stack>
          </ModalBody>
          <ModalFooter>
            <Button
              variant="ghost"
              onClick={toggleModal}
            >
              <Text>Cancel</Text>
            </Button>
            <Button>
              <Text>Apply</Text>
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </ChakraProvider>
  );
};

export default EventGroupAnalysis;
