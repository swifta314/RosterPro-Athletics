//@ts-nocheck

import React, { useState } from 'react';
import { 
  ChakraProvider, 
  Flex, 
  Text, 
  Button, 
  Card, 
  Badge, 
  Grid, 
  InputGroup, 
  InputLeftElement, 
  Input, 
  Table, 
  Thead, 
  Tbody, 
  Tr, 
  Th, 
  Td 
} from '@chakra-ui/react';
import { 
  IconChevronDown, 
  IconDownload, 
  IconSearch 
} from '@tabler/icons-react';
import { kStyleGlobal } from '../../theme';

const PerformanceAnalytics: React.FC = () => {
  const [currentYear] = useState("2023-2024");
  const [selectedGroup, setSelectedGroup] = useState("All");
  const [performanceData] = useState({
    teamPoints: 2834,
    topEvents: ["Sprints", "Jumps", "Throws"],
    improvedAthletes: 12,
    targetMet: 85
  });
  const [eventGroups] = useState(["All", "Sprints", "Distance", "Throws", "Jumps", "Combined"]);
  const [athletes] = useState([
    {
      name: "Sarah Johnson",
      event: "Sprints",
      seasonBest: "10.85s",
      personalBest: "10.72s",
      progress: "+1.2%",
      tier: "Elite"
    },
    {
      name: "Michael Chen",
      event: "Jumps",
      seasonBest: "7.85m",
      personalBest: "7.92m",
      progress: "+0.8%",
      tier: "A"
    }
  ]);

  return (
    <ChakraProvider theme={kStyleGlobal}>
      <Flex
        direction="column"
        p={6}
        gap={6}
      >
        <Flex
          justify="space-between"
          align="center"
          mb={2}
        >
          <Flex direction="column">
            <Text
              fontSize="2xl"
              fontWeight="bold"
            >
              Performance Analytics
            </Text>
            <Flex
              align="center"
              gap={2}
            >
              <Text color="gray.500">
                {currentYear}
              </Text>
              <IconChevronDown 
                size={20} 
                color={kStyleGlobal.colors.gray[400]} 
              />
            </Flex>
          </Flex>
          <Flex gap={4}>
            <Button
              leftIcon={<IconDownload size={20} />}
            >
              Export Data
            </Button>
          </Flex>
        </Flex>
        <Flex
          gap={4}
          overflowX="auto"
          pb={2}
        >
          {eventGroups.map(group => (
            <Button
              key={group}
              variant={selectedGroup === group ? "primary" : "ghost"}
              minW="120px"
              onClick={() => setSelectedGroup(group)}
            >
              {group}
            </Button>
          ))}
        </Flex>
        <Grid
          templateColumns={{
            base: "1fr",
            md: "repeat(4, 1fr)"
          }}
          gap={6}
        >
          <Card>
            <Flex
              direction="column"
              gap={2}
            >
              <Text color="gray.500">
                Total Points
              </Text>
              <Text
                fontSize="3xl"
                fontWeight="bold"
              >
                {performanceData.teamPoints}
              </Text>
              <Badge colorScheme="green">
                +12.5% vs Last Season
              </Badge>
            </Flex>
          </Card>
          <Card>
            <Flex
              direction="column"
              gap={2}
            >
              <Text color="gray.500">
                Top Events
              </Text>
              <Flex
                gap={2}
                wrap="wrap"
              >
                {performanceData.topEvents.map(event => (
                  <Badge 
                    key={event} 
                    colorScheme="blue"
                  >
                    {event}
                  </Badge>
                ))}
              </Flex>
            </Flex>
          </Card>
        </Grid>
        <Card>
          <Flex
            direction="column"
            gap={4}
          >
            <Flex
              justify="space-between"
              align="center"
            >
              <Text
                fontSize="lg"
                fontWeight="bold"
              >
                Athlete Performance
              </Text>
              <InputGroup maxW="300px">
                <InputLeftElement>
                  <IconSearch 
                    size={20} 
                    color={kStyleGlobal.colors.gray[400]} 
                  />
                </InputLeftElement>
                <Input placeholder="Search athletes..." />
              </InputGroup>
            </Flex>
            <Table>
              <Thead>
                <Tr>
                  <Th>Athlete</Th>
                  <Th>Event</Th>
                  <Th>Season Best</Th>
                  <Th>Personal Best</Th>
                  <Th>Progress</Th>
                  <Th>Tier</Th>
                </Tr>
              </Thead>
              <Tbody>
                {athletes.map(athlete => (
                  <Tr key={athlete.name}>
                    <Td>{athlete.name}</Td>
                    <Td>{athlete.event}</Td>
                    <Td>{athlete.seasonBest}</Td>
                    <Td>{athlete.personalBest}</Td>
                    <Td>
                      <Badge colorScheme="green">
                        {athlete.progress}
                      </Badge>
                    </Td>
                    <Td>
                      <Badge colorScheme={athlete.tier === "Elite" ? "purple" : "blue"}>
                        {athlete.tier}
                      </Badge>
                    </Td>
                  </Tr>
                ))}
              </Tbody>
            </Table>
          </Flex>
        </Card>
      </Flex>
    </ChakraProvider>
  );
};

export default PerformanceAnalytics;
