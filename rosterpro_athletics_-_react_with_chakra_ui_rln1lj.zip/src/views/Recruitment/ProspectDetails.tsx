//@ts-nocheck

import React, { useState } from 'react';
import { 
  Box, 
  Flex, 
  Button, 
  Text, 
  Grid, 
  Card, 
  Avatar, 
  Badge, 
  Stack, 
  Modal, 
  ModalOverlay, 
  ModalContent, 
  ModalHeader, 
  ModalCloseButton, 
  ModalBody, 
  ModalFooter, 
  FormControl, 
  FormLabel, 
  Textarea, 
  ChakraProvider 
} from '@chakra-ui/react';
import { 
  IconChevronLeft, 
  IconStar, 
  IconMessage, 
  IconSchool, 
  IconClipboardCheck, 
  IconCertificate 
} from '@tabler/icons-react';
import { useNavigate } from 'react-router-dom';
import { kStyleGlobal } from '../theme';

const ProspectDetails: React.FC = () => {
  const [isWatchlisted, setIsWatchlisted] = useState(false);
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);
  const navigate = useNavigate();

  const prospect = {
    name: "Michael Johnson",
    school: "Stanford University",
    program: "Computer Science",
    classYear: "2024",
    primaryEvents: ["100m Sprint", "200m Sprint"],
    academicStanding: "Good Standing",
    portalEntryDate: "2023-12-01",
    eligibilityRemaining: "2 Years",
    image: "https://images.unsplash.com/photo-1568602471122-7832951cc4c5",
    gpa: "3.8",
    major: "Computer Science",
    transferStatus: "Pending",
    scholarshipStatus: "Full Scholarship"
  };

  const toggleWatchlist = () => {
    setIsWatchlisted(!isWatchlisted);
  };

  const toggleContactModal = () => {
    setIsContactModalOpen(!isContactModalOpen);
  };

  return (
    <ChakraProvider theme={kStyleGlobal}>
      <Box p={6} maxW={"1200px"} mx={"auto"}>
        <Flex mb={8} align={"center"} justify={"space-between"}>
          <Flex align={"center"} gap={4}>
            <Button
              variant={"ghost"}
              onClick={() => navigate("/transfer-portal")}
              leftIcon={<IconChevronLeft size={20} />}
            >
              Back to Transfer Portal
            </Button>
            <Text fontSize={"2xl"} fontWeight={"bold"}>
              Prospect Details
            </Text>
          </Flex>
          <Flex gap={4}>
            <Button
              variant={"secondary"}
              leftIcon={<IconStar size={20} />}
              onClick={toggleWatchlist}
            >
              Add to Watchlist
            </Button>
            <Button
              leftIcon={<IconMessage size={20} />}
              onClick={toggleContactModal}
            >
              Initiate Contact
            </Button>
          </Flex>
        </Flex>
        <Grid
          templateColumns={{
            base: "1fr",
            md: "300px 1fr"
          }}
          gap={8}
        >
          <Card>
            <Flex direction={"column"} align={"center"} textAlign={"center"}>
              <Box position={"relative"} mb={6}>
                <Avatar
                  size={"2xl"}
                  src={prospect.image}
                  mb={2}
                />
                <Badge
                  position={"absolute"}
                  bottom={0}
                  right={0}
                  colorScheme={"green"}
                  borderRadius={"full"}
                >
                  Eligible
                </Badge>
              </Box>
              <Text fontSize={"xl"} fontWeight={"bold"} mb={1}>
                {prospect.name}
              </Text>
              <Text color={"gray.500"} mb={4}>
                {prospect.school}
              </Text>
              <Grid templateColumns={"repeat(2, 1fr)"} gap={4} w={"full"}>
                <Box p={3} bg={"gray.50"} borderRadius={"lg"}>
                  <Text fontSize={"sm"} color={"gray.500"}>
                    Class Year
                  </Text>
                  <Text fontWeight={"medium"}>
                    {prospect.classYear}
                  </Text>
                </Box>
                <Box p={3} bg={"gray.50"} borderRadius={"lg"}>
                  <Text fontSize={"sm"} color={"gray.500"}>
                    Academic Standing
                  </Text