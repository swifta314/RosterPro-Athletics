//@ts-nocheck

import React, { useState } from 'react';
import { 
  ChakraProvider, 
  Flex, 
  Text, 
  Badge, 
  Button, 
  Menu, 
  MenuButton, 
  MenuList, 
  MenuItem, 
  Grid, 
  Card, 
  Center, 
  VStack, 
  CheckboxGroup, 
  Checkbox, 
  RadioGroup, 
  Radio, 
  Tabs, 
  TabList, 
  Tab, 
  Avatar, 
  CircularProgress, 
  CircularProgressLabel 
} from '@chakra-ui/react';
import { 
  IconPlus, 
  IconDotsVertical, 
  IconDownload, 
  IconShare, 
  IconUsers, 
  IconWallet, 
  IconClipboardList 
} from '@tabler/icons-react';
import { kStyleGlobal } from '../theme';
import { useNavigate } from 'react-router-dom';

const TransferPortal = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedTab, setSelectedTab] = useState("incoming");
  const [filterVisible, setFilterVisible] = useState(false);
  const navigate = useNavigate();

  const prospects = [
    {
      "id": 1,
      "name": "Sarah Johnson",
      "image": "https://images.unsplash.com/photo-1544005313-94ddf0286df2",
      "school": "Stanford University",
      "event": "Sprints",
      "personalBest": "11.2s (100m)",
      "matchScore": 92,
      "status": "New"
    },
    {
      "id": 2,
      "name": "Michael Chen",
      "image": "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7",
      "school": "UCLA",
      "event": "Distance",
      "personalBest": "3:45 (1500m)",
      "matchScore": 88,
      "status": "In Progress"
    }
  ];

  const toggleFilter = () => {
    setFilterVisible(!filterVisible);
  };

  const metrics = [
    {
      "label": "Available Roster Spots",
      "value": "8",
      "icon": IconUsers
    },
    {
      "label": "Scholarship Available",
      "value": "$125K",
      "icon": IconWallet
    },
    {
      "label": "Pending Requests",
      "value": "12",
      "icon": IconClipboardList
    }
  ];

  return (
    <ChakraProvider theme={kStyleGlobal}>
      <Flex
        direction="column"
        p={6}
        gap={6}
      >
        <Flex
          justify="space-between"
          align="center"
        >
          <Flex direction="column">
            <Flex
              align="center"
              gap={2}
            >
              <Text
                fontSize="2xl"
                fontWeight="bold"
              >
                Transfer Portal
              </Text>
              <Badge
                colorScheme="primary"
                borderRadius="full"
              >
                5 new
              </Badge>
            </Flex>
          </Flex>
          <Flex gap={4}>
            <Button
              leftIcon={<IconPlus size={20} />}
              onClick={() => setIsModalOpen(true)}
            >
              Add New Prospect
            </Button>
            <Menu>
              <MenuButton
                as={Button}
                variant="ghost"
              >
                <IconDotsVertical size={20} />
              </MenuButton>
              <MenuList>
                <MenuItem icon={<IconDownload size={18} />}>
                  Export List
                </MenuItem>
                <MenuItem icon={<IconShare size={18} />}>
                  Share
                </MenuItem>
              </MenuList>
            </Menu>
          </Flex>
        </Flex>
        <Grid
          templateColumns="repeat(3, 1fr)"
          gap={6}
        >
          {metrics.map(metric => (
            <Card key={metric.label}>
              <Flex
                align="center"
                gap={4}
              >
                <Center
                  bg="primary.50"
                  p={3}
                  borderRadius="xl"
                >
                  <metric.icon
                    size={24}
                    color={kStyleGlobal.colors.primary[500]}
                