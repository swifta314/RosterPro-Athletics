//@ts-nocheck

import React, { useState } from 'react';
import { 
  ChakraProvider, 
  Container, 
  Flex, 
  Button, 
  Text, 
  Grid, 
  Stack, 
  Card, 
  Avatar, 
  Badge, 
  CircularProgress, 
  CircularProgressLabel, 
  Modal, 
  ModalOverlay, 
  ModalContent, 
  ModalHeader, 
  ModalCloseButton, 
  ModalBody, 
  Stat, 
  StatLabel, 
  StatNumber 
} from '@chakra-ui/react';
import { IconArrowLeft, IconEdit, IconMessage } from '@tabler/icons-react';
import { kStyleGlobal } from '../../theme';
import { useNavigate } from 'react-router-dom';

const AthleteDetails: React.FC = () => {
  const navigate = useNavigate();
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isMessageModalOpen, setIsMessageModalOpen] = useState(false);

  const athlete = {
    "name": "Michael Johnson",
    "photo": "https://images.unsplash.com/photo-1500468756762-a401b6f17b46?ixlib=rb-4.0.3",
    "class": "Senior",
    "eligibility": "Active",
    "events": ["Sprints","Relays"],
    "specialties": ["100m","200m","4x100m"],
    "currentSeason": {
     "100m": "10.05s",
     "200m": "20.12s",
     "4x100m": "38.95s"
    },
    "scholarship": {
     "current": 85,
     "timeline": [{
      "year": "2021",
      "percent": 75
     },{
      "year": "2022",
      "percent": 85
     },{
      "year": "2023",
      "percent": 85
     }]
    },
    "academics": {
     "gpa": 3.8,
     "major": "Sports Science",
     "credits": 95,
     "remaining": 25
    }
  };

  const toggleEditModal = () => {
    setIsEditModalOpen(!isEditModalOpen);
  };

  const toggleMessageModal = () => {
    setIsMessageModalOpen(!isMessageModalOpen);
  };

  return (
    <ChakraProvider theme={kStyleGlobal}>
      <Container maxW="7xl" px={8} py={6}>
        <Flex mb={6} align="center" gap={4}>
          <Button 
            variant="ghost" 
            leftIcon={<IconArrowLeft size={20} />} 
            onClick={() => navigate(-1)}
          >
            Back
          </Button>
          <Text fontSize="2xl" fontWeight="bold">
            Athlete Profile - {athlete.name}
          </Text>
        </Flex>
        <Grid 
          templateColumns={{
            base: "1fr",
            lg: "300px 1fr"
          }} 
          gap={8}
        >
          <Stack spacing={6}>
            <Card>
              <Flex 
                direction="column" 
                align="center" 
                textAlign="center" 
                p={6}
              >
                <Avatar 
                  src={athlete.photo} 
                  size="2xl" 
                  mb={4} 
                />
                <Text 
                  fontSize="xl" 
                  fontWeight="bold" 
                  mb={1}
                >
                  {athlete.name}
                </Text>
                <Flex gap={2} mb={4}>
                  <Badge colorScheme="gray">{athlete.class}</Badge>
                  <Badge colorScheme="green">{athlete.eligibility}</Badge>
                </Flex>
                <Flex gap={2} wrap="wrap" justify="center">
                  {athlete.events.map((event, index) => (
                    <Badge key={index} colorScheme="primary" variant="subtle">
                      {event}
                    </Badge>
                  ))}
                </Flex>
                <Flex mt={6} gap={2}>
                  <Button size="sm" onClick={toggleEditModal}>
                    <IconEdit size={18} />
                    Edit Profile
                  </Button>
                  <Button 
                    size="sm" 
                    variant="ghost" 
                    onClick={toggleMessageModal}
                  >
                    <IconMessage size={18} />
                    Message
                  </Button>
                </Flex>
              </Flex>
            </Card>
            <Card>
              <Flex direction="column" p={6}>
                <Flex justify="space-between" align="center" mb={4}>
                  <Text fontSize="lg" fontWeight="bold">
                    Scholarship
                  </Text>
                  <CircularProgress 
                    value={athlete.scholarship.current} 
                    color="primary.500"
                  >
                    <CircularProgressLabel>
                      {athlete.scholarship.current}%
                    </CircularProgressLabel>
                  </CircularProgress>
                </Flex>
                <Stack spacing={4}>
                  {athlete.scholarship.timeline.map((year, index) => (
                    <Flex key={index} justify="space-between">
                      <Text>{year.year}</Text>
                      <Text fontWeight="medium">{year.percent}%</Text>
                    </Flex>
                  ))}
                </Stack>
              </Flex>
            </Card>
          </Stack>
          <Stack spacing={6}>
            <Card>
              <Flex direction="column" p={6}>
                <Flex justify="space-between" align="center" mb={6}>
                  <Text fontSize="lg" fontWeight="bold">
                    Current Season Performance
                  </Text>
                  <Button size="sm" variant="ghost">
                    View Full Analytics
                  </Button>
                </Flex>
                <Grid 
                  templateColumns={{
                    base: "1fr",
                    md: "repeat(3, 1fr)"
                  }} 
                  gap={6}
                >
                  {Object.entries(athlete.currentSeason).map(([event, time], index) => (
                    <Card key={index} bg="gray.50">
                      <Flex direction="column" p={4} align="center">
                        <Text fontSize="sm" color="gray.500">{event}</Text>
                        <Text fontSize="xl" fontWeight="bold">{time}</Text>
                      </Flex>
                    </Card>
                  ))}
                </Grid>
              </Flex>
            </Card>
            <Card>
              <Flex direction="column" p={6}>
                <Text 
                  fontSize="lg" 
                  fontWeight="bold" 
                  mb={6}
                >
                  Academic Status
                </Text>
                <Grid 
                  templateColumns={{
                    base: "1fr",
                    md: "repeat(2, 1fr)"
                  }} 
                  gap={6}
                >
                  <Stat>
                    <StatLabel>Current GPA</StatLabel>
                    <StatNumber fontSize="2xl" fontWeight="bold">
                      {athlete.academics.gpa}
                    </StatNumber>
                  </Stat>
                  <Stat>
                    <StatLabel>Major</StatLabel>
                    <StatNumber fontSize="xl">
                      {athlete.academics.major}
                    </StatNumber>
                  </Stat>
                  <Stat>
                    <StatLabel>Credits Completed</StatLabel>
                    <StatNumber fontSize="xl">
                      {athlete.academics.credits}
                    </StatNumber>
                  </Stat>
                  <Stat>
                    <StatLabel>Credits Remaining</StatLabel>
                    <StatNumber fontSize="xl">
                      {athlete.academics.remaining}
                    </StatNumber>
                  </Stat>
                </Grid>
              </Flex>
            </Card>
          </Stack>
        </Grid>
      </Container>
      <Modal isOpen={isEditModalOpen} onClose={toggleEditModal}>
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Edit Athlete Profile</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            Edit form content here
          </ModalBody>
        </ModalContent>
      </Modal>
      <Modal isOpen={isMessageModalOpen} onClose={toggleMessageModal}>
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Send Message</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            Message form content here
          </ModalBody>
        </ModalContent>
      </Modal>
    </ChakraProvider>
  );
};

export default AthleteDetails;
