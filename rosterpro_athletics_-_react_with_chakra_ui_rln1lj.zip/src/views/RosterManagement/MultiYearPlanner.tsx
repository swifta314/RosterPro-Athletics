//@ts-nocheck

import React, { useState } from 'react';
import { 
  ChakraProvider, 
  Flex, 
  Breadcrumb, 
  BreadcrumbItem, 
  Text, 
  Button, 
  Alert, 
  AlertIcon, 
  Card, 
  Avatar, 
  Badge, 
  Table, 
  Thead, 
  Tbody, 
  Tr, 
  Th, 
  Td,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalCloseButton,
  ModalBody,
  ModalFooter,
  FormControl,
  FormLabel,
  Input,
  Textarea
} from '@chakra-ui/react';
import { 
  IconDownload, 
  IconDeviceFloppy, 
  IconPlus, 
  IconChevronLeft, 
  IconChevronRight 
} from '@tabler/icons-react';
import { kStyleGlobal } from '../theme';

const MultiYearPlanner = () => {
  const [isScenarioModalOpen, setIsScenarioModalOpen] = useState(false);
  const [currentYear, setCurrentYear] = useState(2024);
  const [selectedView, setSelectedView] = useState("semester");
  const [athletes] = useState([
    {
      "name": "John Smith",
      "year": "Freshman",
      "eventGroup": "Sprints",
      "scholarship": "Full",
      "image": "https://images.unsplash.com/photo-1519311965067-36d3e5f33d39"
    },
    {
      "name": "Emma Wilson",
      "year": "Sophomore",
      "eventGroup": "Distance",
      "scholarship": "Partial",
      "image": "https://images.unsplash.com/photo-1552058544-f2b08422138a"
    }
  ]);

  const toggleScenarioModal = () => {
    setIsScenarioModalOpen(!isScenarioModalOpen);
  };

  return (
    <ChakraProvider theme={kStyleGlobal}>
      <Flex
        direction="column"
        minH="100vh"
        bg="background"
        p={6}
        gap={6}
      >
        <Flex
          justify="space-between"
          align="center"
          mb={4}
        >
          <Flex
            direction="column"
            gap={1}
          >
            <Breadcrumb>
              <BreadcrumbItem>
                <Text>Dashboard</Text>
              </BreadcrumbItem>
              <BreadcrumbItem isCurrentPage>
                <Text>Multi-Year Planner</Text>
              </BreadcrumbItem>
            </Breadcrumb>
            <Text
              fontSize="2xl"
              fontWeight="bold"
            >
              Multi-Year Planner (2024-2028)
            </Text>
          </Flex>
          <Flex gap={3}>
            <Button
              leftIcon={<IconDownload size={20} />}
            >
              Export Plan
            </Button>
            <Button
              leftIcon={<IconDeviceFloppy size={20} />}
            >
              Save Changes
            </Button>
            <Button
              variant="primary"
              leftIcon={<IconPlus size={20} />}
              onClick={toggleScenarioModal}
            >
              Create Scenario
            </Button>
          </Flex>
        </Flex>
        <Alert
          status="warning"
          borderRadius="xl"
        >
          <AlertIcon />
          <Text>Some athletes may exceed eligibility limits in the current plan. Please review.</Text>
        </Alert>
        <Card>
          <Flex
            justify="space-between"
            align="center"
            mb={6}
          >
            <Flex gap={4}>
              <Button
                variant={selectedView === "semester" ? "primary" : "ghost"}
                size="sm"
              >
                Semester View
              </Button>
              <Button
                variant={selectedView === "year" ? "primary" : "ghost"}
                size="sm"
              >
                Year View
              </Button>
            </Flex>
            <Flex
              gap={2}
              align="center"
            >
              <Button
                variant="ghost"
                p={2}
              >
                <IconChevronLeft size={20} />
              </Button>
              <Text
                fontWeight="medium"
              >
                {currentYear}
              </Text>
              <Button
                variant="ghost"
                p={2}
              >
                <IconChevronRight size={20} />
              </Button>
            </Flex>
          </Flex>
          <Table>
            <Thead>
              <Tr>
                <Th>Event Group</Th>
                <Th>Freshman</Th>
                <Th>Sophomore</Th>
                <Th>Junior</Th>
                <Th>Senior</Th>
              </Tr>
            </Thead>
            <Tbody>
              {athletes.map((athlete, index) => (
                <Tr key={index}>
                  <Td>
                    <Flex
                      gap={3}
                      align="center"
                    >
                      <Avatar
                        src={athlete.image}
                        size="sm"
                      />
                      <Flex direction="column">
                        <Text
                          fontWeight="medium"
                        >
                          {athlete.name}
                        </Text>
                        <Text
                          fontSize="sm"
                          color="gray.500"
                        >
                          {athlete.eventGroup}
                        </Text>
                      </Flex>
                    </Flex>
                  </Td>
                  <Td>
                    <Badge colorScheme={athlete.scholarship === "Full" ? "green" : "orange"}>
                      {athlete.scholarship}
                    </Badge>
                  </Td>
                  <Td />
                  <Td />
                  <Td />
                </Tr>
              ))}
            </Tbody>
          </Table>
        </Card>
        <Modal
          isOpen={isScenarioModalOpen}
          onClose={toggleScenarioModal}
        >
          <ModalOverlay />
          <ModalContent>
            <ModalHeader>
              Create New Scenario
            </ModalHeader>
            <ModalCloseButton />
            <ModalBody>
              <FormControl mb={4}>
                <FormLabel>
                  Scenario Name
                </FormLabel>
                <Input placeholder="Enter scenario name" />
              </FormControl>
              <FormControl>
                <FormLabel>
                  Description
                </FormLabel>
                <Textarea placeholder="Enter scenario description" />
              </FormControl>
            </ModalBody>
            <ModalFooter>
              <Button
                variant="ghost"
                onClick={toggleScenarioModal}
              >
                Cancel
              </Button>
              <Button>
                Create
              </Button>
            </ModalFooter>
          </ModalContent>
        </Modal>
      </Flex>
    </ChakraProvider>
  );
};

export default MultiYearPlanner;
