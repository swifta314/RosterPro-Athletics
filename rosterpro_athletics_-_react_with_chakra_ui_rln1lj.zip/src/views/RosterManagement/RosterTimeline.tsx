//@ts-nocheck

import React, { useState } from 'react';
import { 
  Box, 
  Flex, 
  Select, 
  ButtonGroup, 
  Button, 
  Stack, 
  Grid, 
  Badge, 
  Modal, 
  ModalOverlay, 
  ModalContent, 
  ModalHeader, 
  ModalCloseButton, 
  ModalBody, 
  ModalFooter, 
  FormControl, 
  FormLabel, 
  ChakraProvider 
} from '@chakra-ui/react';
import { 
  IconPrinter, 
  IconDownload, 
  IconChevronRight 
} from '@tabler/icons-react';
import { kStyleGlobal } from '../../theme';

const RosterTimeline: React.FC = () => {
  const currentYear = 2024;
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedScale, setSelectedScale] = useState("semester");
  const [selectedYear, setSelectedYear] = useState(currentYear);
  
  const years = [
    currentYear, 
    currentYear + 1, 
    currentYear + 2, 
    currentYear + 3, 
    currentYear + 4
  ];
  
  const eventGroups = ["Sprint", "Distance", "Throws", "Jumps", "Multi"];
  
  const athletes = [
    {
      "id": 1,
      "name": "John Smith",
      "group": "Sprint",
      "eligibility": "2024-2026",
      "scholarship": "Full",
      "status": "Active"
    },
    {
      "id": 2,
      "name": "Sarah Johnson",
      "group": "Distance",
      "eligibility": "2023-2025",
      "scholarship": "Partial",
      "status": "Redshirt"
    }
  ];

  const toggleModal = () => {
    setIsModalOpen(!isModalOpen);
  };

  const toggleScale = () => {
    setSelectedScale(prevScale => 
      prevScale === "semester" ? "year" : "semester"
    );
  };

  return (
    <ChakraProvider theme={kStyleGlobal}>
      <Box p={6}>
        <Flex
          justify="space-between"
          mb={6}
          align="center"
        >
          <Flex
            gap={4}
            align="center"
          >
            <Select
              value={selectedYear}
              w="200px"
              bg="white"
              borderRadius="xl"
            >
              {years.map(year => (
                <option
                  value={year}
                  key={year}
                >
                  {year + " Academic Year"}
                </option>
              ))}
            </Select>
            <ButtonGroup>
              <Button
                variant={selectedScale === "semester" ? "primary" : "secondary"}
                onClick={toggleScale}
              >
                Semester View
              </Button>
              <Button
                variant={selectedScale === "year" ? "primary" : "secondary"}
                onClick={toggleScale}
              >
                Year View
              </Button>
            </ButtonGroup>
          </Flex>
          <Flex gap={3}>
            <Button
              leftIcon={<IconPrinter size={20} />}
              variant="secondary"
            >
              Print View
            </Button>
            <Button
              leftIcon={<IconDownload size={20} />}
              variant="secondary"
            >
              Export
            </Button>
          </Flex>
        </Flex>
        <Box
          bg="white"
          borderRadius="xl"
          p={6}
          overflowX="auto"
        >
          <Grid
            templateColumns="200px 1fr"
            gap={6}
            minW="1000px"
          >
            <Stack spacing={4}>
              {eventGroups.map(group => (
                <Flex
                  key={group}
                  p={4}
                  bg="gray.50"
                  borderRadius="lg"
                  align="center"
                  justify="space-between"
                >
                  {group}
                  <IconChevronRight size={20} />
                </Flex>
              ))}
            </Stack>
            <Grid
              templateColumns="repeat(8, 1fr)"
              gap={4}
            >
              {athletes.map(athlete => (
                <Box
                  key={athlete.id}
                  bg="primary.50"
                  p={4}
                  borderRadius="lg"
                  borderLeft="4px"
                  borderLeftColor="primary.500"
                  cursor="pointer"
                  onClick={toggleModal}
                >
                  <Flex
                    direction="column"
                    gap={2}
                  >
                    <Box fontWeight="bold">
                      {athlete.name}
                    </Box>
                    <Flex
                      gap={2}
                      align="center"
                    >
                      <Badge colorScheme="green">
                        {athlete.scholarship}
                      </Badge>
                      <Badge colorScheme="blue">
                        {athlete.status}
                      </Badge>
                    </Flex>
                  </Flex>
                </Box>
              ))}
            </Grid>
          </Grid>
        </Box>
      </Box>
      <Modal
        isOpen={isModalOpen}
        onClose={toggleModal}
      >
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>
            Athlete Details
          </ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <Stack spacing={4}>
              <FormControl>
                <FormLabel>
                  Status
                </FormLabel>
                <Select>
                  <option value="active">
                    Active
                  </option>
                  <option value="redshirt">
                    Redshirt
                  </option>
                </Select>
              </FormControl>
              <FormControl>
                <FormLabel>
                  Scholarship
                </FormLabel>
                <Select>
                  <option value="full">
                    Full
                  </option>
                  <option value="partial">
                    Partial
                  </option>
                </Select>
              </FormControl>
            </Stack>
          </ModalBody>
          <ModalFooter>
            <Button
              variant="ghost"
              onClick={toggleModal}
            >
              Cancel
            </Button>
            <Button>
              Save Changes
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </ChakraProvider>
  );
};

export default RosterTimeline;
