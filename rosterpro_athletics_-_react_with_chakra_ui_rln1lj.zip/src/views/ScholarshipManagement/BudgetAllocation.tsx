//@ts-nocheck

import React, { useState } from 'react';
import { 
  Box, 
  Flex, 
  Text, 
  Select, 
  Button, 
  Card, 
  Badge, 
  TableContainer, 
  Table, 
  Thead, 
  Tbody, 
  Tr, 
  Th, 
  Td, 
  Progress, 
  Modal, 
  ModalOverlay, 
  ModalContent, 
  ModalHeader, 
  ModalCloseButton, 
  ModalBody, 
  ModalFooter, 
  FormControl, 
  FormLabel, 
  Input,
  ChakraProvider
} from '@chakra-ui/react';
import { 
  IconRefresh, 
  IconDeviceFloppy, 
  IconPencil, 
  IconCircleCheck, 
  IconFileAnalytics, 
  IconArrowLeft 
} from '@tabler/icons-react';
import { kStyleGlobal } from '../theme';
import { useNavigate } from 'react-router-dom';

const BudgetAllocation = () => {
  const currentYear = 2024;
  const years = [currentYear, currentYear + 1, currentYear + 2, currentYear + 3, currentYear + 4];
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedEventGroup, setSelectedEventGroup] = useState(null);
  const [budgetData, setBudgetData] = useState({
    total: 1000000,
    allocated: 750000,
    groups: [
      {
        name: "Track & Field",
        allocation: 300000,
        gender: { men: 60, women: 40 }
      },
      {
        name: "Swimming",
        allocation: 250000,
        gender: { men: 45, women: 55 }
      },
      {
        name: "Basketball",
        allocation: 200000,
        gender: { men: 50, women: 50 }
      }
    ]
  });

  const navigate = useNavigate();

  const toggleModal = () => {
    setIsModalOpen(!isModalOpen);
  };

  return (
    <ChakraProvider theme={kStyleGlobal}>
      <Box p={8} bg="background" minH="100vh">
        <Flex justify="space-between" mb={8} align="center">
          <Flex direction="column">
            <Text fontSize="2xl" fontWeight="bold">Budget Allocation</Text>
            <Flex align="center" gap={2}>
              <Select bg="white" w="200px" borderRadius="xl" defaultValue={currentYear}>
                {years.map(year => (
                  <option key={year} value={year}>
                    {year} Academic Year
                  </option>
                ))}
              </Select>
            </Flex>
          </Flex>
          <Flex gap={4}>
            <Button variant="secondary">
              <IconRefresh size={20} />
              <Text ml={2}>Reset</Text>
            </Button>
            <Button>
              <IconDeviceFloppy size={20} />
              <Text ml={2}>Save Changes</Text>
            </Button>
          </Flex>
        </Flex>
        <Flex 
          templateColumns={{
            base: "1fr",
            lg: "2fr 1fr"
          }} 
          gap={6}
        >
          <Card>
            <Flex justify="space-between" mb={6}>
              <Text fontSize="lg" fontWeight="bold">Budget Overview</Text>
              <Badge 
                colorScheme={budgetData.allocated / budgetData.total <= 1 ? "green" : "red"}
                borderRadius="xl"
              >
                {`${Math.round(budgetData.allocated / budgetData.total * 100)}% Allocated`}
              </Badge>
            </Flex>
            <TableContainer>
              <Table variant="simple" w="full">
                <Thead>
                  <Tr>
                    <Th>Event Group</Th>
                    <Th>Current Allocation</Th>
                    <Th>Gender Distribution</Th>
                    <Th>Actions</Th>
                  </Tr>
                </Thead>
                <Tbody>
                  {budgetData.groups.map(group => (
                    <Tr key={group.name}>
                      <Td>{group.name}</Td>
                      <Td>${group.allocation.toLocaleString()}</Td>
                      <Td>
                        <Flex align="center" gap={2}>
                          <Progress 
                            value={group.gender.men} 
                            w="100px" 
                            colorScheme="blue" 
                            size="sm" 
                          />
                          <Text fontSize="sm">
                            {`${group.gender.men}/${group.gender.women}`}
                          </Text>
                        </Flex>
                      </Td>
                      <Td>
                        <Button 
                          size="sm" 
                          variant="ghost" 
                          onClick={() => {
                            setSelectedEventGroup(group);
                            toggleModal();
                          }}
                        >
                          <IconPencil size={18} />
                        </Button>
                      </Td>
                    </Tr>
                  ))}
                </Tbody>
              </Table>
            </TableContainer>
          </Card>
          <Card>
            <Flex direction="column" gap={6}>
              <Text fontSize="lg" fontWeight="bold">Compliance Status</Text>
              <Flex 
                direction="column" 
                bg="green.50" 
                p={4} 
                borderRadius="xl" 
                border="1px" 
                borderColor="green.200"
              >
                <Flex justify="space-between" mb={2}>
                  <Text fontWeight="medium">Title IX Compliance</Text>
                  <IconCircleCheck 
                    size={20} 
                    color={kStyleGlobal.colors.success} 
                  />
                </Flex>
                <Text fontSize="sm" color="gray.600">
                  Current allocation meets gender equity requirements
                </Text>
              </Flex>
              <Flex direction="column" gap={4}>
                <Text fontWeight="medium">Quick Actions</Text>
                <Button 
                  variant="secondary" 
                  w="full" 
                  onClick={() => navigate("/reports")}
                >
                  <IconFileAnalytics size={20} />
                  <Text ml={2}>Generate Report</Text>
                </Button>
                <Button 
                  variant="secondary" 
                  w="full" 
                  onClick={() => navigate("/scholarship-tracker")}
                >
                  <IconArrowLeft size={20} />
                  <Text ml={2}>Back to Tracker</Text>
                </Button>
              </Flex>
            </Flex>
          </Card>
        </Flex>
      </Box>
      <Modal isOpen={isModalOpen} onClose={toggleModal}>
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Edit Allocation</ModalHeader>
          <ModalCloseButton />
          <ModalBody>
            <Flex direction="column" gap={4}>
              <FormControl>
                <FormLabel>Budget Amount</FormLabel>
                <Input type="number" placeholder="Enter amount" />
              </FormControl>
              <FormControl>
                <FormLabel>Gender Distribution</FormLabel>
                <Flex gap={4}>
                  <Input type="number" placeholder="Men %" />
                  <Input type="number" placeholder="Women %" />
                </Flex>
              </FormControl>
            </Flex>
          </ModalBody>
          <ModalFooter>
            <Button variant="ghost" mr={3} onClick={toggleModal}>
              Cancel
            </Button>
            <Button>Save Changes</Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </ChakraProvider>
  );
};

export default BudgetAllocation;
