//@ts-nocheck

import React, { useState } from 'react';
import { 
  ChakraProvider, 
  Box, 
  Flex, 
  Text, 
  Select, 
  Button, 
  Grid, 
  Card, 
  Table, 
  Thead, 
  Tbody, 
  Tr, 
  Th, 
  Td, 
  Progress, 
  Badge, 
  InputGroup, 
  InputLeftElement, 
  Input, 
  IconButton, 
  Stack 
} from '@chakra-ui/react';
import { 
  IconPlus, 
  IconDownload, 
  IconCoin, 
  IconWallet, 
  IconUsers, 
  IconDotsVertical, 
  IconSearch, 
  IconEdit, 
  IconEye, 
  IconRefresh, 
  IconChartBar 
} from '@tabler/icons-react';
import { kStyleGlobal } from '../../theme';

const ScholarshipTracker: React.FC = () => {
  const [currentYear, setCurrentYear] = useState("2023-2024");
  const [isModalOpen, setIsModalOpen] = useState(false);

  const scholarshipStats = {
    total: 125,
    available: 45,
    committed: 80
  };

  const eventGroups = [
    {
      name: "Track",
      allocated: 45,
      total: 60,
      gender: {
        male: 25,
        female: 20
      }
    },
    {
      name: "Field",
      allocated: 35,
      total: 40,
      gender: {
        male: 20,
        female: 15
      }
    },
    {
      name: "Cross Country",
      allocated: 25,
      total: 25,
      gender: {
        male: 12,
        female: 13
      }
    }
  ];

  const athletes = [
    {
      name: "Michael Brown",
      event: "Track",
      year: "Senior",
      amount: 25000,
      status: "Active"
    },
    {
      name: "Sarah Wilson",
      event: "Field",
      year: "Junior",
      amount: 20000,
      status: "Pending"
    },
    {
      name: "James Davis",
      event: "Cross Country",
      year: "Sophomore",
      amount: 15000,
      status: "Active"
    }
  ];

  const toggleModal = () => {
    setIsModalOpen(!isModalOpen);
  };

  return (
    <ChakraProvider theme={kStyleGlobal}>
      <Box p={6} bg="background" minH="100vh">
        <Flex justify="space-between" mb={8} align="center">
          <Flex direction="column" gap={2}>
            <Flex align="center" gap={3}>
              <Text fontSize="2xl" fontWeight="bold">Scholarship Tracker</Text>
              <Select w="200px" value={currentYear}>
                <option value="2023-2024">2023-2024 Academic Year</option>
                <option value="2024-2025">2024-2025 Academic Year</option>
              </Select>
            </Flex>
          </Flex>
          <Flex gap={4}>
            <Button 
              onClick={toggleModal} 
              leftIcon={<IconPlus size={20} />}
            >
              Add New Scholarship
            </Button>
            <Button 
              variant="secondary" 
              leftIcon={<IconDownload size={20} />}
            >
              Export Report
            </Button>
          </Flex>
        </Flex>

        <Grid templateColumns="repeat(3, 1fr)" gap={6} mb={8}>
          <Card 
            icon={<IconCoin size={24} />}
            label="Total Scholarships"
            value={scholarshipStats.total}
            trend="+12%"
            trendDir="up"
          />
          <Card 
            icon={<IconWallet size={24} />}
            label="Available Scholarships"
            value={scholarshipStats.available}
            trend="-5%"
            trendDir="down"
          />
          <Card 
            icon={<IconUsers size={24} />}
            label="Committed Scholarships"
            value={scholarshipStats.committed}
            trend="+8%"
            trendDir="up"
          />
        </Grid>

        <Grid templateColumns="2fr 1fr" gap={6}>
          <Flex direction="column" gap={6}>
            <Card>
              <Flex justify="space-between" mb={6}>
                <Text fontSize="lg" fontWeight="semibold">Scholarship Distribution</Text>
                <Button size="sm" variant="ghost">
                  <IconDotsVertical size={20} />
                </Button>
              </Flex>
              <Table>
                <Thead>
                  <Tr>
                    <Th>Event Group</Th>
                    <Th>Allocated</Th>
                    <Th>Total</Th>
                    <Th>Gender Distribution</Th>
                  </Tr>
                </Thead>
                <Tbody>
                  {eventGroups.map((group, index) => (
                    <Tr key={index}>
                      <Td>{group.name}</Td>
                      <Td>{group.allocated}</Td>
                      <Td>{group.total}</Td>
                      <Td>
                        <Flex align="center" gap={2}>
                          <Progress value={70} w="100px" size="sm" colorScheme="blue" />
                          <Text>{`${group.gender.male}M/${group.gender.female}F`}</Text>
                        </Flex>
                      </Td>
                    </Tr>
                  ))}
                </Tbody>
              </Table>
            </Card>

            <Card>
              <Flex justify="space-between" mb={6}>
                <Text fontSize="lg" fontWeight="semibold">Athletes List</Text>
                <InputGroup maxW="300px">
                  <InputLeftElement>
                    <IconSearch size={20} color="gray.400" />
                  </InputLeftElement>
                  <Input placeholder="Search athletes..." />
                </InputGroup>
              </Flex>
              <Table>
                <Thead>
                  <Tr>
                    <Th>Name</Th>
                    <Th>Event</Th>
                    <Th>Year</Th>
                    <Th>Amount</Th>
                    <Th>Status</Th>
                    <Th>Actions</Th>
                  </Tr>
                </Thead>
                <Tbody>
                  {athletes.map((athlete, index) => (
                    <Tr key={index}>
                      <Td>{athlete.name}</Td>
                      <Td>{athlete.event}</Td>
                      <Td>{athlete.year}</Td>
                      <Td>${athlete.amount}</Td>
                      <Td>
                        <Badge colorScheme={athlete.status === "Active" ? "green" : "yellow"}>
                          {athlete.status}
                        </Badge>
                      </Td>
                      <Td>
                        <Flex gap={2}>
                          <IconButton 
                            aria-label="Edit" 
                            icon={<IconEdit size={18} />} 
                            size="sm" 
                          />
                          <IconButton 
                            aria-label="View" 
                            icon={<IconEye size={18} />} 
                            size="sm" 
                          />
                        </Flex>
                      </Td>
                    </Tr>
                  ))}
                </Tbody>
              </Table>
            </Card>
          </Flex>

          <Flex direction="column" gap={6}>
            <Card>
              <Flex justify="space-between" mb={6}>
                <Text fontSize="lg" fontWeight="semibold">Multi-Year Projection</Text>
                <Button size="sm" variant="ghost">
                  <IconRefresh size={20} />
                </Button>
              </Flex>
              <Stack spacing={4}>
                {[2024, 2025, 2026, 2027].map((year, index) => (
                  <Box key={index}>
                    <Flex justify="space-between" mb={2}>
                      <Text fontWeight="medium">{year}</Text>
                      <Text>{`${Math.floor(Math.random() * 30 + 70)}%`}</Text>
                    </Flex>
                    <Progress 
                      value={Math.random() * 30 + 70} 
                      size="sm" 
                      colorScheme="blue" 
                    />
                  </Box>
                ))}
              </Stack>
            </Card>

            <Card bg="primary.50">
              <Flex 
                direction="column" 
                align="center" 
                textAlign="center" 
                gap={4}
              >
                <IconChartBar size={40} color="primary.500" />
                <Text fontSize="lg" fontWeight="bold">Compliance Status</Text>
                <Text color="gray.600">
                  Your scholarship distribution is compliant with Title IX requirements
                </Text>
                <Button size="sm" variant="primary">
                  View Details
                </Button>
              </Flex>
            </Card>
          </Flex>
        </Grid>
      </Box>
    </ChakraProvider>
  );
};

export default ScholarshipTracker;
